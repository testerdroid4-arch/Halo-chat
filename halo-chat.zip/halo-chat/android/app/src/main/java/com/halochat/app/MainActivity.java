package com.halochat.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
