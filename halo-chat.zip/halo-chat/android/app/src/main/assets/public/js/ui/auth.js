/* Halo — sign-in / sign-up card. Only used when the Supabase backend is configured. */
(function (H) {
  'use strict';
  const U = H.U;
  const A = {};

  A.show = (note) => new Promise((resolve) => {
    let mode = 'in';
    const keep = { mail: '', name: '' }; // typed values survive an error message
    const wrap = document.createElement('div');
    wrap.className = 'auth';
    document.getElementById('overlays').appendChild(wrap);

    const draw = (err, info) => {
      wrap.innerHTML = '<form class="auth-card glass" novalidate>' +
        '<div class="brand">' + H.logo(40) + 'Halo</div>' +
        '<p class="lead">' + (mode === 'in' ? 'Welcome back. Sign in to see your chats.' : 'Create an account to start messaging.') + '</p>' +
        (mode === 'up' ? '<label class="field"><span>Display name</span><input class="input" id="a-name" maxlength="40" autocomplete="name" value="' + U.esc(keep.name) + '" required></label>' : '') +
        '<label class="field"><span>Email</span><input class="input" id="a-mail" type="email" autocomplete="email" inputmode="email" value="' + U.esc(keep.mail) + '" required></label>' +
        '<label class="field"><span>Password</span><input class="input" id="a-pass" type="password" minlength="6" autocomplete="' + (mode === 'in' ? 'current-password' : 'new-password') + '" required></label>' +
        '<p class="err" role="alert">' + U.esc(err || '') + '</p>' + (info ? '<p class="lead" style="color:var(--ok)">' + U.esc(info) + '</p>' : '') +
        '<button class="btn primary block" id="a-go" type="submit">' + (mode === 'in' ? 'Sign in' : 'Create account') + '</button>' +
        '<button class="link-btn" type="button" id="a-sw">' + (mode === 'in' ? 'New here? Create an account' : 'Have an account? Sign in') + '</button>' +
        (note ? '<p class="lead" style="font-size:.85em">' + U.esc(note) + '</p>' : '') + '</form>';
      wrap.querySelector('#a-sw').onclick = () => { mode = mode === 'in' ? 'up' : 'in'; draw(); };
      wrap.querySelector('form').onsubmit = async (e) => {
        e.preventDefault();
        const mail = wrap.querySelector('#a-mail').value.trim(), pass = wrap.querySelector('#a-pass').value;
        const name = mode === 'up' ? wrap.querySelector('#a-name').value.trim() : '';
        keep.mail = mail; keep.name = name;
        if (!/^\S+@\S+\.\S+$/.test(mail)) return draw('Enter a valid email address.');
        if (pass.length < 6) return draw('Use a password with at least 6 characters.');
        if (mode === 'up' && !name) return draw('Add a display name so people know who you are.');
        const btn = wrap.querySelector('#a-go'); btn.disabled = true; btn.textContent = 'Please wait…';
        try {
          const r = mode === 'in' ? await H.backend.signIn(mail, pass) : await H.backend.signUp(mail, pass, name);
          if (r.signedIn) { wrap.remove(); resolve(); } else if (r.needsConfirm) { mode = 'in'; draw('', 'Check your inbox to confirm your email, then sign in.'); }
        } catch (x) { draw(x.message || 'Something went wrong. Try again.'); }
      };
    };
    draw();
  });

  H.auth = A;
})(window.Halo = window.Halo || {});
