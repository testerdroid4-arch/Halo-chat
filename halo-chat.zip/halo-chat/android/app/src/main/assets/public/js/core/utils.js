/* Halo — small, dependency-free helpers. Everything hangs off the global `Halo` namespace
   so the project runs from file:// without a bundler or ES-module CORS issues. */
(function (H) {
  'use strict';
  const U = {};
  const WD = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  U.uid = (p = 'id') => p + '_' + Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-4);
  U.esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  U.escRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  U.pad = (n) => String(n).padStart(2, '0');
  U.rand = (a, b) => a + Math.random() * (b - a);
  U.sample = (arr) => arr[Math.floor(Math.random() * arr.length)];
  U.wait = (ms) => new Promise((r) => setTimeout(r, ms));

  U.time = (ts) => { const d = new Date(ts); return U.pad(d.getHours()) + ':' + U.pad(d.getMinutes()); };
  U.startOfDay = (ts) => { const d = new Date(ts); d.setHours(0, 0, 0, 0); return d.getTime(); };
  U.dayDiff = (ts) => Math.round((U.startOfDay(Date.now()) - U.startOfDay(ts)) / 864e5);
  U.dayLabel = (ts) => {
    const n = U.dayDiff(ts);
    if (n === 0) return 'Today';
    if (n === 1) return 'Yesterday';
    const d = new Date(ts);
    if (n > 1 && n < 7) return WD[d.getDay()];
    return d.getDate() + ' ' + MON[d.getMonth()] + ' ' + d.getFullYear();
  };
  U.listTime = (ts) => {
    const n = U.dayDiff(ts);
    if (n === 0) return U.time(ts);
    if (n === 1) return 'Yesterday';
    if (n > 1 && n < 7) return WD[new Date(ts).getDay()].slice(0, 3);
    const d = new Date(ts);
    return U.pad(d.getDate()) + '/' + U.pad(d.getMonth() + 1) + '/' + String(d.getFullYear()).slice(2);
  };
  U.lastSeen = (ts) => {
    if (!ts) return 'offline';
    const n = U.dayDiff(ts);
    if (n === 0) return 'last seen today at ' + U.time(ts);
    if (n === 1) return 'last seen yesterday at ' + U.time(ts);
    const d = new Date(ts);
    return 'last seen ' + d.getDate() + ' ' + MON[d.getMonth()];
  };
  U.fileSize = (b) => {
    if (b < 1024) return b + ' B';
    if (b < 1048576) return Math.round(b / 1024) + ' KB';
    return (b / 1048576).toFixed(1) + ' MB';
  };
  U.ext = (name) => ((String(name).split('.').pop() || 'file') + '').slice(0, 5).toUpperCase();
  U.initials = (name) => {
    const w = String(name || '?').trim().split(/\s+/).filter(Boolean);
    return ((w[0] || '?')[0] + (w.length > 1 ? w[w.length - 1][0] : '')).toUpperCase();
  };
  U.debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
  U.svgData = (svg) => 'data:image/svg+xml;utf8,' + encodeURIComponent(svg);

  /* Downscale a picked image to a JPEG data URL. Keeps localStorage small and uploads fast. */
  U.resizeImage = (file, max = 1024, quality = 0.8) => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Could not read the file'));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('That file is not a readable image'));
      img.onload = () => {
        const s = Math.min(1, max / Math.max(img.width, img.height));
        const c = document.createElement('canvas');
        c.width = Math.max(1, Math.round(img.width * s));
        c.height = Math.max(1, Math.round(img.height * s));
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        resolve(c.toDataURL('image/jpeg', quality));
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });

  /* Safe copy: async clipboard first, textarea fallback. */
  U.copy = async (text) => {
    try { await navigator.clipboard.writeText(text); return true; } catch (e) { /* fall through */ }
    try {
      const t = document.createElement('textarea');
      t.value = text; t.setAttribute('readonly', ''); t.style.cssText = 'position:fixed;opacity:0';
      document.body.appendChild(t); t.select();
      const ok = document.execCommand('copy'); t.remove(); return ok;
    } catch (e) { return false; }
  };

  H.U = U;
})(window.Halo = window.Halo || {});
