/* Halo — the one-to-one conversation screen: header, message list, composer, attachments,
   emoji, voice notes, reactions, replies, delete, in-chat search. */
(function (H) {
  'use strict';
  const U = H.U, C = H.C;
  const $ = (s, r = document) => r.querySelector(s);
  const CV = {};

  let cur = null;          // open chat id
  let host = null;
  let replyId = null;
  let emojiOpen = false, emojiTab = 'recent';
  let search = { on: false, q: '', hits: [], i: 0 };
  let stick = true, newCount = 0, lastCount = 0, firstRender = true;
  let rec = null;          // active recording
  let player = null;       // active voice playback
  let typingSent = 0;
  let sel = null;          // Set of selected message ids while in selection mode, else null

  const chat = () => H.store.chat(cur);
  const contact = () => { const c = chat(); return c && H.store.contact(c.contactId); };
  const nameOf = (from) => (from === 'me' ? 'You' : (H.store.contact(from) || {}).name || 'Unknown');
  const settings = () => H.store.get().settings;

  /* ---------- skeleton ---------- */
  function build() {
    host.innerHTML =
      '<section class="chat" aria-label="Conversation">' +
      '<div class="wallpaper"></div>' +
      '<header class="chat-head glass glass-strong">' +
      '<button class="icon-btn back-btn" data-act="back" aria-label="Back to chats">' + H.icon('back', 24) + '</button>' +
      '<button class="who" data-act="info" aria-label="Contact info"><span id="ch-av"></span><span class="t"><b id="ch-name"></b><small id="ch-status"></small></span></button>' +
      '<button class="icon-btn" data-act="search" aria-label="Search in chat">' + H.icon('search', 21) + '</button>' +
      '<button class="icon-btn" data-act="menu" aria-label="Chat options">' + H.icon('more', 21) + '</button></header>' +
      '<header class="chat-head sel-head glass glass-strong" id="sel-head" hidden>' +
      '<button class="icon-btn" data-act="sel-close" aria-label="Cancel selection">' + H.icon('x', 22) + '</button>' +
      '<b class="sel-count" id="sel-count">0</b>' +
      '<button class="icon-btn" data-act="sel-reply" id="sel-reply" aria-label="Reply">' + H.icon('reply', 21) + '</button>' +
      '<button class="icon-btn" data-act="sel-copy" aria-label="Copy">' + H.icon('copy', 21) + '</button>' +
      '<button class="icon-btn danger" data-act="sel-del" aria-label="Delete selected">' + H.icon('trash', 21) + '</button></header>' +
      '<div class="searchbar glass glass-strong" id="ch-search" hidden><input class="input" id="ch-q" placeholder="Search in this chat" aria-label="Search in this chat" autocomplete="off">' +
      '<span class="count" id="ch-count" aria-live="polite"></span>' +
      '<button class="icon-btn" data-act="hit-prev" aria-label="Previous match">' + H.icon('arrow-up', 20) + '</button>' +
      '<button class="icon-btn" data-act="hit-next" aria-label="Next match">' + H.icon('arrow-down', 20) + '</button>' +
      '<button class="icon-btn" data-act="search" aria-label="Close search">' + H.icon('x', 20) + '</button></div>' +
      '<div class="scroller" id="scroller"><div class="list" id="msgs" role="log" aria-live="polite" aria-label="Messages"></div></div>' +
      '<button class="to-bottom glass" id="to-bottom" data-act="bottom" aria-label="Jump to latest message" hidden>' + H.icon('arrow-down', 22) + '<span class="badge" id="nb" hidden></span></button>' +
      '<footer class="composer-wrap"><div id="reply-slot"></div><div id="emoji-slot"></div>' +
      '<div class="composer glass glass-strong" id="composer"></div></footer>' +
      '<input type="file" id="f-img" accept="image/*" multiple hidden><input type="file" id="f-cam" accept="image/*" capture="environment" hidden><input type="file" id="f-doc" hidden></section>';
    drawComposer();
  }

  function drawComposer() {
    const c = $('#composer');
    if (rec) {
      c.innerHTML = '<button class="icon-btn" data-act="rec-cancel" aria-label="Cancel recording">' + H.icon('trash', 21) + '</button>' +
        '<div class="recorder"><span class="rec-dot"></span><span class="rt" id="rt">0:00</span><div class="wave" aria-hidden="true">' + C.waveBars('rec' + Date.now(), 26) + '</div></div>' +
        '<button class="send" data-act="rec-send" aria-label="Send voice message">' + H.icon('send', 20) + '</button>';
      return;
    }
    const has = !!($('#ta') && $('#ta').value.trim());
    const draft = chat() ? chat().draft : '';
    c.innerHTML = '<button class="icon-btn ' + (emojiOpen ? 'on' : '') + '" data-act="emoji" aria-label="Emoji" aria-pressed="' + emojiOpen + '">' + H.icon('smile', 23) + '</button>' +
      '<textarea id="ta" rows="1" placeholder="Message" aria-label="Type a message" enterkeyhint="' + (settings().enterToSend ? 'send' : 'enter') + '"></textarea>' +
      '<button class="icon-btn" data-act="attach" aria-label="Attach a photo or file">' + H.icon('paperclip', 22) + '</button>' +
      '<button class="send" id="sendbtn" data-act="send" aria-label="Send message" hidden>' + H.icon('send', 20) + '</button>' +
      '<button class="send" id="micbtn" data-act="mic" aria-label="Record a voice message" style="background:var(--glass-3);color:var(--fg);box-shadow:none">' + H.icon('mic', 22) + '</button>';
    const ta = $('#ta');
    ta.value = has ? $('#ta').value : draft || '';
    sizeTa(); toggleSend();
  }
  function sizeTa() { const ta = $('#ta'); if (!ta) return; ta.style.height = 'auto'; ta.style.height = Math.min(ta.scrollHeight, 140) + 'px'; }
  function toggleSend() {
    const ta = $('#ta'); if (!ta) return;
    const has = !!ta.value.trim();
    $('#sendbtn').hidden = !has; $('#micbtn').hidden = has;
  }

  /* ---------- header ---------- */
  function statusText() {
    const c = chat(), ct = contact();
    if (!c || !ct) return ['', false];
    if (c.typing) return ['typing…', true];
    if (ct.online) return ['online', true];
    return [U.lastSeen(ct.lastSeen), false];
  }
  function drawHeader() {
    const ct = contact(); if (!ct) return;
    const av = $('#ch-av'); const h = C.avatar(ct, 42, ct.online);
    if (av._h !== h) { av._h = h; av.innerHTML = h; }
    $('#ch-name').textContent = ct.name;
    const [t, live] = statusText();
    const s = $('#ch-status'); s.textContent = t; s.classList.toggle('live', live);
  }

  /* ---------- messages ---------- */
  function findMsg(id) { const c = chat(); return c && c.messages.find((m) => m.id === id); }

  function quoteHtml(m) {
    const o = findMsg(m.replyTo);
    let who = 'Message', txt = 'Original message is unavailable';
    if (o) { who = nameOf(o.from); txt = o.deleted ? 'This message was deleted' : (o.type === 'image' ? 'Photo' + (o.text ? ': ' + o.text : '') : o.type === 'voice' ? 'Voice message' : o.type === 'file' ? (o.file ? o.file.name : 'File') : o.text); }
    return '<button class="quote" data-act="quote" data-id="' + U.esc(m.replyTo) + '"><b>' + U.esc(who) + '</b><span>' + U.esc(txt) + '</span></button>';
  }

  function msgHtml(m, cont) {
    const out = m.from === 'me';
    const q = search.on ? search.q : '';
    const meta = '<span class="meta">' + U.time(m.ts) + (out && !m.deleted ? C.tick(m.status || 'read') : '') + '</span>';
    let inner = '', cls = '';
    if (m.deleted) {
      cls = 'deleted';
      inner = '<div class="txt">' + H.icon('info', 14) + (out ? 'You deleted this message' : 'This message was deleted') + '</div>';
    } else {
      if (m.replyTo) inner += quoteHtml(m);
      if (m.type === 'image') {
        cls = 'media';
        const edge = '<span class="meta edge-meta">' + U.time(m.ts) + (out ? C.tick(m.status || 'read') : '') + '</span>';
        inner += '<button class="photo" data-act="img" aria-label="Open photo"><img src="' + U.esc(m.src) + '" alt="' + U.esc(m.text || 'Photo') + '" loading="lazy" draggable="false">' + (m.text ? '' : edge) + '</button>' +
          (m.text ? '<div class="txt">' + C.richText(m.text, q) + meta + '</div>' : '');
      } else if (m.type === 'file') {
        const f = m.file || { name: 'File', size: 0 };
        inner += '<button class="file" data-act="file" aria-label="File ' + U.esc(f.name) + '"><span class="fi">' + H.icon('file', 20) + U.esc(U.ext(f.name)) + '</span><span class="fn"><b>' + (q ? C.hi(f.name, q) : U.esc(f.name)) + '</b><small>' + U.fileSize(f.size) + '</small></span></button>' + meta;
      } else if (m.type === 'voice') {
        inner += '<div class="voice ' + (!out && !m.heard ? 'unheard' : '') + '"><button class="play" data-act="play" aria-label="Play voice message">' + H.icon('play', 18) + '</button><div class="wave" data-wave>' + C.waveBars(m.id) + '</div><span class="dur">' + C.mmss(m.dur || 0) + '</span></div>' + meta;
      } else {
        inner += '<div class="txt">' + C.richText(m.text, q) + meta + '</div>';
      }
    }
    const reacts = !m.deleted && m.reactions && m.reactions.length ? '<div class="reacts">' + groupReacts(m.reactions) + '</div>' : '';
    const picked = sel && sel.has(m.id);
    return '<div class="msg ' + (out ? 'out' : 'in') + (cont ? ' cont' : '') + (reacts ? ' has-react' : '') + (sel ? ' selmode' : '') + (picked ? ' selected' : '') + '" data-id="' + U.esc(m.id) + '">' +
      (sel ? '<span class="chk" aria-hidden="true">' + H.icon('check', 14) + '</span>' : '') + '<div class="stack">' +
      '<div class="bubble ' + cls + '" role="article" aria-label="' + (out ? 'You' : U.esc(nameOf(m.from))) + ' at ' + U.time(m.ts) + '">' + inner + '</div>' + reacts +
      (m.deleted ? '' : '<button class="more-btn" data-act="more" aria-label="Message options">' + H.icon('chevron', 15, 'rot') + '</button>') + '</div></div>';
  }
  function groupReacts(rs) {
    const g = {};
    rs.forEach((r) => { (g[r.emoji] = g[r.emoji] || []).push(r.by); });
    return Object.keys(g).map((e) => '<button class="react ' + (g[e].includes('me') ? 'mine' : '') + '" data-act="react-chip" data-e="' + e + '" aria-label="' + e + ' ' + g[e].length + '">' + e + (g[e].length > 1 ? '<small>' + g[e].length + '</small>' : '') + '</button>').join('');
  }

  function buildItems() {
    const c = chat(); const items = [];
    if (H.backend.mode === 'local') items.push({ key: 'sys0', html: '<div class="sys">' + H.icon('lock', 12) + ' Demo mode. Messages and replies are simulated on this device and never leave it.</div>' });
    let prevDay = null, prev = null;
    c.messages.forEach((m) => {
      const d = U.startOfDay(m.ts);
      if (d !== prevDay) { items.push({ key: 'd' + d, html: '<div class="day">' + U.dayLabel(m.ts) + '</div>' }); prevDay = d; prev = null; }
      const cont = prev && prev.from === m.from && m.ts - prev.ts < 5 * 60000;
      items.push({ key: m.id, html: msgHtml(m, cont) });
      prev = m;
    });
    if (!c.messages.length) items.push({ key: 'empty', html: '<div class="sys">No messages yet. Say hello to ' + U.esc(contact().name) + ' 👋</div>' });
    if (c.typing) items.push({ key: 'typing', html: '<div class="msg in"><div class="stack"><div class="bubble typing-bubble" aria-label="' + U.esc(contact().name) + ' is typing"><i></i><i></i><i></i></div></div></div>' });
    return items;
  }

  function reconcile(list, items, initial) {
    const old = new Map();
    [...list.children].forEach((n) => old.set(n.dataset.k, n));
    const nodes = items.map((it) => {
      const n = old.get(it.key);
      if (n && n._h === it.html) return n;
      const t = document.createElement('div'); t.innerHTML = it.html;
      const nn = t.firstElementChild; nn._h = it.html; nn.dataset.k = it.key;
      if (initial || n) nn.style.animation = 'none';
      return nn;
    });
    let cursor = list.firstChild;
    nodes.forEach((n) => { if (cursor === n) cursor = cursor.nextSibling; else list.insertBefore(n, cursor); });
    while (cursor) { const nx = cursor.nextSibling; cursor.remove(); cursor = nx; }
  }

  function renderMessages() {
    const c = chat(); if (!c) return;
    const sc = $('#scroller'), list = $('#msgs');
    const nearBottom = sc.scrollHeight - sc.scrollTop - sc.clientHeight < 90;
    const added = c.messages.length - lastCount;
    reconcile(list, buildItems(), firstRender);
    applyPlayback();
    applyHit(false);
    if (firstRender) { sc.style.scrollBehavior = 'auto'; sc.scrollTop = sc.scrollHeight; sc.style.scrollBehavior = ''; firstRender = false; }
    else if (added > 0) {
      const lastM = c.messages[c.messages.length - 1];
      if (nearBottom || (lastM && lastM.from === 'me')) toBottom(); else if (lastM && lastM.from !== 'me') { newCount += added; drawJump(); }
    } else if (c.typing && nearBottom) toBottom();
    lastCount = c.messages.length;
  }
  function toBottom() { const sc = $('#scroller'); sc.scrollTop = sc.scrollHeight; newCount = 0; drawJump(); }
  function drawJump() {
    const sc = $('#scroller'); if (!sc) return;
    const far = sc.scrollHeight - sc.scrollTop - sc.clientHeight > 220;
    $('#to-bottom').hidden = !far;
    const nb = $('#nb'); nb.hidden = !newCount; nb.textContent = newCount;
  }

  /* ---------- in-chat search ---------- */
  function runSearch() {
    const q = search.q.trim().toLowerCase();
    search.hits = q ? chat().messages.filter((m) => !m.deleted && ((m.text || '').toLowerCase().includes(q) || (m.file && m.file.name.toLowerCase().includes(q)))).map((m) => m.id) : [];
    search.i = Math.max(0, search.hits.length - 1);
    $('#ch-count').textContent = q ? (search.hits.length ? (search.i + 1) + ' of ' + search.hits.length : 'No match') : '';
    renderMessages(); applyHit(true);
  }
  function applyHit(scroll) {
    document.querySelectorAll('#msgs mark.cur').forEach((m) => m.classList.remove('cur'));
    if (!search.on || !search.hits.length) return;
    const el = $('#msgs .msg[data-id="' + search.hits[search.i] + '"]');
    if (!el) return;
    const mk = el.querySelector('mark'); if (mk) mk.classList.add('cur');
    if (scroll) el.scrollIntoView({ block: 'center', behavior: 'smooth' });
  }
  function stepHit(d) {
    if (!search.hits.length) return;
    search.i = (search.i + d + search.hits.length) % search.hits.length;
    $('#ch-count').textContent = (search.i + 1) + ' of ' + search.hits.length;
    applyHit(true);
  }
  function toggleSearch(on) {
    search.on = on === undefined ? !search.on : on;
    $('#ch-search').hidden = !search.on;
    if (search.on) $('#ch-q').focus(); else { search.q = ''; $('#ch-q').value = ''; search.hits = []; renderMessages(); }
  }

  /* ---------- voice playback ---------- */
  function stopPlayer() {
    if (!player) return;
    if (player.audio) { player.audio.pause(); player.audio = null; }
    clearInterval(player.timer);
    const id = player.id; player = null; paintPlayer(id, 0, false);
  }
  function paintPlayer(id, p, playing, el) {
    const row = el || $('#msgs .msg[data-id="' + id + '"]'); if (!row) return;
    const bars = row.querySelectorAll('.wave i'); const n = Math.round(bars.length * p);
    bars.forEach((b, i) => b.classList.toggle('done', i < n));
    const pb = row.querySelector('.play'); if (pb) { pb.innerHTML = H.icon(playing ? 'pause' : 'play', 18); pb.setAttribute('aria-label', playing ? 'Pause voice message' : 'Play voice message'); }
    const m = findMsg(id);
    const d = row.querySelector('.dur'); if (d && m) d.textContent = C.mmss(playing || p > 0 ? Math.round((m.dur || 0) * p) : m.dur || 0);
  }
  function applyPlayback() { if (player) paintPlayer(player.id, player.p || 0, true); }
  function play(id) {
    if (player && player.id === id) { stopPlayer(); return; }
    stopPlayer();
    const m = findMsg(id); if (!m) return;
    if (m.from !== 'me' && !m.heard) H.store.commit(() => { m.heard = true; }, true), $('#msgs .msg[data-id="' + id + '"] .voice').classList.remove('unheard');
    player = { id, p: 0 };
    const dur = Math.max(1, m.dur || 1);
    const end = () => { if (player && player.id === id) stopPlayer(); };
    if (m.audio) {
      const a = new Audio(m.audio); player.audio = a;
      a.ontimeupdate = () => { if (player && player.audio === a && a.duration) { player.p = a.currentTime / a.duration; paintPlayer(id, player.p, true); } };
      a.onended = end;
      a.onerror = () => { player.audio = null; simulate(); };
      a.play().catch(() => { player && (player.audio = null); simulate(); });
    } else simulate();
    function simulate() {
      const t0 = Date.now();
      clearInterval(player.timer);
      player.timer = setInterval(() => { if (!player) return; player.p = Math.min(1, (Date.now() - t0) / (dur * 1000)); paintPlayer(id, player.p, true); if (player.p >= 1) end(); }, 100);
    }
    paintPlayer(id, 0, true);
  }

  /* ---------- sending ---------- */
  function send() {
    const ta = $('#ta'); if (!ta) return;
    const text = ta.value.trim(); if (!text) return;
    H.backend.send(cur, Object.assign({ type: 'text', text }, replyId ? { replyTo: replyId } : {}));
    ta.value = ''; clearReply(); sizeTa(); toggleSend(); H.backend.setDraft(cur, '');
    if (emojiOpen) toggleEmoji(false);
    ta.focus({ preventScroll: true });
  }
  function setReply(id) {
    const m = findMsg(id); if (!m) return;
    replyId = id;
    $('#reply-slot').innerHTML = '<div class="replybar glass glass-strong"><div class="rq"><b>' + U.esc('Replying to ' + nameOf(m.from)) + '</b><span>' + U.esc(H.notify.preview(m)) + '</span></div><button class="icon-btn" data-act="reply-x" aria-label="Cancel reply">' + H.icon('x', 20) + '</button></div>';
    $('#ta') && $('#ta').focus({ preventScroll: true });
  }
  function clearReply() { replyId = null; const s = $('#reply-slot'); if (s) s.innerHTML = ''; }

  async function sendFiles(files, kind, caption) {
    for (let i = 0; i < files.length; i++) {
      const f = files[i];
      if (f.size > 12 * 1048576) { H.overlay.toast(f.name + ' is larger than 12 MB.'); continue; }
      try {
        const up = await H.backend.upload(f, kind);
        if (kind === 'image') H.backend.send(cur, { type: 'image', src: up.src, text: i === 0 ? caption || '' : '', replyTo: i === 0 && replyId ? replyId : undefined });
        else H.backend.send(cur, { type: 'file', file: up.file || { name: f.name, size: f.size } });
      } catch (e) { H.overlay.toast('Could not attach ' + f.name + '. ' + (e.message || '')); }
    }
    clearReply();
  }

  function photoSheet(files) {
    const imgs = [...files].filter((f) => f.type.startsWith('image/'));
    if (!imgs.length) return H.overlay.toast('Please pick an image file.');
    const urls = imgs.map((f) => URL.createObjectURL(f));
    const sh = H.overlay.sheet({
      title: imgs.length > 1 ? imgs.length + ' photos' : 'Send photo',
      html: '<div style="display:grid;grid-template-columns:repeat(' + Math.min(imgs.length, 3) + ',1fr);gap:8px">' + urls.map((u) => '<img src="' + u + '" alt="Selected photo" style="width:100%;aspect-ratio:' + (imgs.length > 1 ? '1' : '4/3') + ';object-fit:cover;border-radius:18px">').join('') + '</div>' +
        '<label class="field"><span>Caption (optional)</span><input class="input" id="pc" maxlength="300" placeholder="Add a caption" autocomplete="off"></label>' +
        '<button class="btn primary block" id="ps">' + H.icon('send', 18) + 'Send</button>',
      onClose: () => urls.forEach((u) => URL.revokeObjectURL(u)),
      onMount(el) {
        const go = async () => { const cap = el.querySelector('#pc').value.trim(); el.querySelector('#ps').disabled = true; sh.close(); await sendFiles(imgs, 'image', cap); };
        el.querySelector('#ps').onclick = go;
        el.querySelector('#pc').addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
      }
    });
  }

  function attachSheet() {
    const sh = H.overlay.sheet({
      title: 'Attach', flush: true,
      html: '<div class="attach-grid"><button data-k="img"><span class="orb" style="background:linear-gradient(135deg,#8b7bff,#5b4de0)">' + H.icon('image', 24) + '</span>Photos</button>' +
        '<button data-k="cam"><span class="orb" style="background:linear-gradient(135deg,#ff8a6b,#e8573f)">' + H.icon('camera', 24) + '</span>Camera</button>' +
        '<button data-k="doc"><span class="orb" style="background:linear-gradient(135deg,#34d1b8,#0b8f77)">' + H.icon('file', 24) + '</span>File</button></div>',
      onMount(el) {
        el.addEventListener('click', (e) => { const b = e.target.closest('[data-k]'); if (!b) return; sh.close(); $('#f-' + b.dataset.k).click(); });
      }
    });
  }

  /* ---------- emoji ---------- */
  function toggleEmoji(on) {
    emojiOpen = on === undefined ? !emojiOpen : on;
    const slot = $('#emoji-slot');
    if (!emojiOpen) { slot.innerHTML = ''; const b = $('[data-act="emoji"]'); if (b) { b.classList.remove('on'); b.setAttribute('aria-pressed', 'false'); } return; }
    const b = $('[data-act="emoji"]'); b.classList.add('on'); b.setAttribute('aria-pressed', 'true');
    if ($('#ta')) $('#ta').blur();
    slot.innerHTML = '<div class="emoji-panel glass glass-strong"><div class="emoji-tabs" role="tablist"></div><div class="emoji-grid"></div></div>';
    drawEmoji();
  }
  function drawEmoji() {
    const rec = settings().recentEmoji || [];
    const tabs = [{ id: 'recent', icon: '🕘', label: 'Recent' }].concat(H.emoji);
    $('.emoji-tabs').innerHTML = tabs.map((t) => '<button role="tab" aria-selected="' + (t.id === emojiTab) + '" data-tab="' + t.id + '" aria-label="' + t.label + '">' + t.icon + '</button>').join('');
    const cat = emojiTab === 'recent' ? { label: 'Recently used', list: rec.length ? rec : H.quickReactions } : H.emoji.find((e) => e.id === emojiTab);
    $('.emoji-grid').innerHTML = '<div class="lbl">' + cat.label + '</div>' + cat.list.map((e) => '<button data-e="' + e + '" aria-label="' + e + '">' + e + '</button>').join('');
  }
  function insertEmoji(e) {
    let ta = $('#ta'); if (!ta) return;
    const a = ta.selectionStart == null ? ta.value.length : ta.selectionStart, b = ta.selectionEnd == null ? a : ta.selectionEnd;
    ta.value = ta.value.slice(0, a) + e + ta.value.slice(b);
    ta.selectionStart = ta.selectionEnd = a + e.length;
    sizeTa(); toggleSend(); saveDraft();
    H.store.commit((s) => { s.settings.recentEmoji = [e].concat((s.settings.recentEmoji || []).filter((x) => x !== e)).slice(0, 24); }, true);
  }

  /* ---------- voice recording ---------- */
  async function startRec() {
    if (rec) return;
    rec = { t0: Date.now(), chunks: [], mr: null, stream: null, sim: false };
    let ok = false;
    try {
      if (navigator.mediaDevices && window.MediaRecorder) {
        rec.stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const types = ['audio/webm;codecs=opus', 'audio/mp4', 'audio/webm'];
        const mt = types.find((t) => MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported(t));
        rec.mr = new MediaRecorder(rec.stream, Object.assign({ audioBitsPerSecond: 24000 }, mt ? { mimeType: mt } : {}));
        rec.mr.ondataavailable = (e) => { if (e.data && e.data.size) rec.chunks.push(e.data); };
        rec.mr.start(250);
        ok = true;
      }
    } catch (e) { ok = false; }
    if (!ok) { rec.sim = true; H.overlay.toast('Microphone unavailable. Recording a simulated voice note instead.', { ms: 3800 }); }
    rec.t0 = Date.now();
    drawComposer();
    rec.timer = setInterval(() => {
      const s = (Date.now() - rec.t0) / 1000;
      const rt = $('#rt'); if (rt) rt.textContent = C.mmss(s);
      if (s >= 120) finishRec(true);
    }, 250);
  }
  function endRecHardware() {
    clearInterval(rec.timer);
    if (rec.stream) rec.stream.getTracks().forEach((t) => t.stop());
  }
  function cancelRec() { if (!rec) return; try { rec.mr && rec.mr.state !== 'inactive' && rec.mr.stop(); } catch (e) { /* ignore */ } endRecHardware(); rec = null; drawComposer(); }
  async function finishRec(send) {
    if (!rec) return;
    const r = rec; const dur = Math.max(1, Math.round((Date.now() - r.t0) / 1000));
    let blob = null;
    if (r.mr && r.mr.state !== 'inactive') {
      blob = await new Promise((res) => { r.mr.onstop = () => res(new Blob(r.chunks, { type: r.mr.mimeType || 'audio/webm' })); r.mr.stop(); });
    }
    endRecHardware(); rec = null; drawComposer();
    if (!send) return;
    let up = {};
    try { if (blob && blob.size) up = await H.backend.upload(blob, 'voice'); } catch (e) { H.overlay.toast('Voice upload failed: ' + e.message); return; }
    H.backend.send(cur, { type: 'voice', dur, audio: up.audio, heard: true, replyTo: replyId || undefined });
    clearReply();
    if (!up.audio && !r.sim) H.overlay.toast('Voice note is too long to store in demo mode, sent without audio.');
  }

  /* ---------- message menu & delete ---------- */
  function msgMenu(row, pt) {
    const id = row.dataset.id; const m = findMsg(id); if (!m || m.deleted) return;
    const mine = (m.reactions || []).find((r) => r.by === 'me');
    const bub = row.querySelector('.bubble').getBoundingClientRect();
    H.overlay.menu({
      rect: pt ? undefined : bub, x: pt && pt.x, y: pt && pt.y,
      quick: H.quickReactions, mine: mine && mine.emoji,
      onQuick: (e) => H.backend.react(cur, id, e),
      items: [
        { icon: 'reply', label: 'Reply', fn: () => setReply(id) },
        (m.type === 'text' || m.text) && { icon: 'copy', label: 'Copy text', fn: async () => H.overlay.toast((await U.copy(m.text)) ? 'Copied' : 'Could not copy') },
        { icon: 'check-circle', label: 'Select', fn: () => startSel(id) },
        { icon: 'trash', label: 'Delete', danger: true, fn: () => deleteMsg(id) }
      ]
    });
  }

  /* ---------- multi-select (copy / reply / delete several messages) ---------- */
  function drawSel() {
    const on = !!sel;
    const h = $('#sel-head'), top = $('.chat-head:not(.sel-head)'); if (!h) return;
    h.hidden = !on; if (top) top.hidden = on;
    if (on) {
      $('#sel-count').textContent = sel.size + ' selected';
      $('#sel-reply').hidden = sel.size !== 1;
    }
    renderMessages();
  }
  function startSel(id) { sel = new Set([id]); drawSel(); }
  function toggleSel(id) {
    if (!sel) return;
    if (sel.has(id)) sel.delete(id); else sel.add(id);
    if (!sel.size) sel = null;
    drawSel();
  }
  function endSel() { if (!sel) return; sel = null; drawSel(); }
  const selMsgs = () => (chat() ? chat().messages.filter((m) => sel && sel.has(m.id)) : []);
  async function copySel() {
    const txt = selMsgs().filter((m) => !m.deleted && m.text).map((m) => m.text).join('\n');
    if (!txt) { H.overlay.toast('Nothing to copy in the selected messages.'); return; }
    H.overlay.toast((await U.copy(txt)) ? 'Copied' : 'Could not copy'); endSel();
  }
  async function deleteSel() {
    const list = selMsgs(); if (!list.length) return endSel();
    const allMine = list.every((m) => m.from === 'me' && !m.deleted);
    const n = list.length;
    const r = await H.overlay.confirm({ title: n === 1 ? 'Delete message?' : 'Delete ' + n + ' messages?', text: allMine ? 'Remove them just for you, or for everyone in this chat.' : 'This removes the messages from your device only.', ok: 'Delete for me', danger: true, extra: allMine ? 'Delete for everyone' : null });
    if (r !== true && r !== 'extra') return;
    const ids = list.map((m) => m.id); sel = null; drawSel();
    ids.forEach((id) => H.backend.remove(cur, id, r === 'extra'));
  }
  async function deleteMsg(id) {
    const m = findMsg(id); if (!m) return;
    const mine = m.from === 'me';
    const r = await H.overlay.confirm({ title: 'Delete message?', text: mine ? 'You can remove it just for you, or for everyone in this chat.' : 'This removes the message from your device only.', ok: 'Delete for me', danger: true, extra: mine ? 'Delete for everyone' : null });
    if (r === true) H.backend.remove(cur, id, false);
    else if (r === 'extra') H.backend.remove(cur, id, true);
  }

  function headerMenu() {
    const c = chat(), r = $('[data-act="menu"]').getBoundingClientRect();
    H.overlay.menu({
      rect: { left: r.right - 40, width: 0, bottom: r.bottom, top: r.top },
      items: [
        { icon: 'user', label: 'Contact info', fn: () => H.lists.contactSheet(c.contactId) },
        { icon: 'search', label: 'Search in chat', fn: () => toggleSearch(true) },
        { icon: c.muted ? 'bell' : 'bell-off', label: c.muted ? 'Unmute notifications' : 'Mute notifications', fn: () => H.backend.patchChat(c.id, { muted: !c.muted }) },
        { icon: c.archived ? 'unarchive' : 'archive', label: c.archived ? 'Unarchive chat' : 'Archive chat', fn: () => { H.lists.toggleArchive(c.id); if (!c.archived) H.nav.back(); } },
        { icon: 'palette', label: 'Chat theme', fn: () => H.settings.themeSheet() },
        { icon: 'broom', label: 'Clear messages', danger: true, fn: () => CV.clear(c.id) },
        { icon: 'trash', label: 'Delete chat', danger: true, fn: () => CV.removeChat(c.id) }
      ]
    });
  }

  CV.clear = async (id) => { if (await H.overlay.confirm({ title: 'Clear messages?', text: 'All messages in this chat will be removed from your device.', ok: 'Clear', danger: true })) H.backend.clearChat(id); };
  CV.removeChat = async (id) => {
    if (await H.overlay.confirm({ title: 'Delete this chat?', text: 'The conversation and its messages will be removed from your list.', ok: 'Delete', danger: true })) {
      if (cur === id) H.nav.back(); H.backend.deleteChat(id);
    }
  };

  function saveDraft() { if (cur && $('#ta')) H.backend.setDraft(cur, $('#ta').value); }

  /* ---------- lifecycle ---------- */
  CV.open = (id) => {
    if (cur === id && $('#msgs')) return;
    if (cur) { saveDraft(); stopPlayer(); if (rec) cancelRec(); }
    cur = id; host = host || $('#chat-host');
    sel = null; replyId = null; emojiOpen = false; search = { on: false, q: '', hits: [], i: 0 }; newCount = 0; firstRender = true; lastCount = 0;
    build(); drawHeader(); renderMessages(); drawJump();
    H.backend.markRead(id);
    if (H.backend.watchChat) H.backend.watchChat(id);
  };
  CV.close = () => { sel = null; if (!cur) return; saveDraft(); stopPlayer(); if (rec) cancelRec(); toggleEmoji(false); cur = null; };
  CV.update = () => {
    if (!cur) return;
    if (!chat()) { H.nav.back(); return; }
    drawHeader();
    renderMessages();
    const c = chat(); if (c.unread && document.visibilityState === 'visible') H.backend.markRead(cur);
  };
  CV.current = () => cur;

  CV.bind = () => {
    host = $('#chat-host');
    host.addEventListener('click', (e) => {
      const a = e.target.closest('[data-act]'); const row = e.target.closest('.msg');
      if (sel && row && row.dataset.id) { e.preventDefault(); toggleSel(row.dataset.id); return; }
      if (!a) { const em = e.target.closest('.emoji-grid [data-e]'); if (em) insertEmoji(em.dataset.e); const tb = e.target.closest('.emoji-tabs [data-tab]'); if (tb) { emojiTab = tb.dataset.tab; drawEmoji(); } return; }
      switch (a.dataset.act) {
        case 'back': if (sel) endSel(); else H.nav.back(); break;
        case 'sel-close': endSel(); break;
        case 'sel-copy': copySel(); break;
        case 'sel-del': deleteSel(); break;
        case 'sel-reply': { const m = selMsgs()[0]; if (m && !m.deleted) { setReply(m.id); endSel(); $('#ta') && $('#ta').focus(); } else endSel(); break; }
        case 'info': H.lists.contactSheet(chat().contactId); break;
        case 'search': toggleSearch(); break;
        case 'hit-prev': stepHit(-1); break;
        case 'hit-next': stepHit(1); break;
        case 'menu': headerMenu(); break;
        case 'bottom': toBottom(); break;
        case 'send': send(); break;
        case 'emoji': toggleEmoji(); break;
        case 'attach': attachSheet(); break;
        case 'mic': startRec(); break;
        case 'rec-cancel': cancelRec(); break;
        case 'rec-send': finishRec(true); break;
        case 'reply-x': clearReply(); break;
        case 'img': { const m = findMsg(row.dataset.id); if (m) H.overlay.lightbox(m.src); break; }
        case 'file': { const m = findMsg(row.dataset.id); if (m && m.file && m.file.url) window.open(m.file.url, '_blank', 'noopener'); else H.overlay.toast('Demo mode keeps only the file name and size, not its contents.'); break; }
        case 'play': play(row.dataset.id); break;
        case 'more': msgMenu(row); break;
        case 'react-chip': H.backend.react(cur, row.dataset.id, a.dataset.e); break;
        case 'quote': {
          const t = $('#msgs .msg[data-id="' + a.dataset.id + '"]');
          if (!t) return H.overlay.toast('That message is no longer in this chat.');
          t.scrollIntoView({ block: 'center', behavior: 'smooth' }); t.classList.remove('flash'); void t.offsetWidth; t.classList.add('flash'); break;
        }
      }
    });
    host.addEventListener('dblclick', (e) => { const b = e.target.closest('.bubble'); if (b && !e.target.closest('a,button')) H.backend.react(cur, b.closest('.msg').dataset.id, '❤️'); });
    H.pressable(host, '.bubble:not(.typing-bubble)', (el, pt) => { const row = el.closest('.msg'); if (sel) toggleSel(row.dataset.id); else msgMenu(row, pt); });
    host.addEventListener('keydown', (e) => { if (e.key === 'Escape' && sel) endSel(); });
    host.addEventListener('input', (e) => {
      if (e.target.id === 'ta') {
        sizeTa(); toggleSend(); saveDraft();
        if (H.backend.setTyping && Date.now() - typingSent > 2500 && e.target.value) { typingSent = Date.now(); H.backend.setTyping(cur, true); }
      } else if (e.target.id === 'ch-q') { search.q = e.target.value; runSearch(); }
    });
    host.addEventListener('keydown', (e) => {
      if (e.target.id === 'ta' && e.key === 'Enter' && !e.shiftKey && !e.isComposing && settings().enterToSend) { e.preventDefault(); send(); }
      else if (e.target.id === 'ch-q' && e.key === 'Enter') { e.preventDefault(); stepHit(e.shiftKey ? -1 : 1); }
      else if (e.key === 'Escape' && search.on) toggleSearch(false);
    });
    host.addEventListener('focusin', (e) => { if (e.target.id === 'ta' && emojiOpen) toggleEmoji(false); });
    host.addEventListener('scroll', (e) => { if (e.target.id === 'scroller') { const sc = e.target; if (sc.scrollHeight - sc.scrollTop - sc.clientHeight < 90) newCount = 0; drawJump(); } }, true);
    host.addEventListener('change', (e) => {
      const t = e.target; if (!t.files || !t.files.length) return;
      if (t.id === 'f-img' || t.id === 'f-cam') photoSheet(t.files);
      else if (t.id === 'f-doc') sendFiles(t.files, 'file');
      t.value = '';
    });
    document.addEventListener('visibilitychange', () => { if (cur && document.visibilityState === 'visible') H.backend.markRead(cur); });
    // drag & drop files onto the conversation
    host.addEventListener('dragover', (e) => { if (cur) e.preventDefault(); });
    host.addEventListener('drop', (e) => {
      if (!cur || !e.dataTransfer || !e.dataTransfer.files.length) return;
      e.preventDefault();
      const fs = [...e.dataTransfer.files];
      if (fs.every((f) => f.type.startsWith('image/'))) photoSheet(fs); else sendFiles(fs, 'file');
    });
    // paste image from clipboard
    host.addEventListener('paste', (e) => {
      const fs = [...(e.clipboardData ? e.clipboardData.files : [])].filter((f) => f.type.startsWith('image/'));
      if (fs.length) { e.preventDefault(); photoSheet(fs); }
    });
  };

  H.chatView = CV;
})(window.Halo = window.Halo || {});
