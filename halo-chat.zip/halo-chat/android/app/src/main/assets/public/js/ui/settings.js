/* Halo — Settings tab, profile editor, chat theme picker, backend/feature-status sheet. */
(function (H) {
  'use strict';
  const U = H.U, C = H.C;
  const $ = (s, r = document) => r.querySelector(s);
  const S = {};
  const st = () => H.store.get();

  const THEMES = [
    ['aurora', 'Aurora', 'linear-gradient(135deg,#7cf7d4,#2fc7b0)'],
    ['dusk', 'Dusk', 'linear-gradient(135deg,#a99bff,#6a58ea)'],
    ['ember', 'Ember', 'linear-gradient(135deg,#f0643f,#c62e5f)'],
    ['forest', 'Forest', 'linear-gradient(135deg,#7bea9f,#25a56c)'],
    ['mono', 'Slate', 'linear-gradient(135deg,#55657c,#36445a)']
  ];

  S.set = (path, val) => {
    H.store.commit((s) => {
      const p = path.split('.'); let o = s.settings;
      while (p.length > 1) o = o[p.shift()];
      o[p[0]] = val;
    });
    H.applyTheme();
  };
  const get = (path) => path.split('.').reduce((o, k) => (o ? o[k] : undefined), st().settings);

  const seg = (key, opts) => '<span class="seg" role="group">' + opts.map(([v, t]) => '<button data-seg="' + key + '" data-v="' + v + '" aria-pressed="' + (get(key) === v) + '">' + t + '</button>').join('') + '</span>';
  const sim = () => (H.backend.mode === 'local' ? C.chipSim : '');

  S.render = () => {
    const s = st(), me = s.me, remote = H.backend.mode === 'supabase';
    const html =
      '<button class="profile-card glass" data-act="profile" aria-label="Edit your profile">' + C.avatar(me, 68) +
      '<span class="grow"><h3>' + U.esc(me.name) + '</h3><p>' + U.esc(me.about || '') + '</p></span><span style="color:var(--fg3)">' + H.icon('edit', 20) + '</span></button>' +

      '<div class="set-group glass"><h4>Appearance</h4>' +
      '<div class="set-row"><span class="ico">' + H.icon('moon', 18) + '</span><span class="txt"><b>Theme</b></span>' + seg('theme', [['dark', 'Dark'], ['light', 'Light'], ['system', 'Auto']]) + '</div>' +
      '<div class="set-row"><span class="ico">' + H.icon('palette', 18) + '</span><span class="txt"><b>Chat theme</b><small>Bubble colours and wallpaper glow</small></span></div>' +
      '<div class="swatches">' + THEMES.map(([id, n, g]) => '<button class="swatch" data-seg="chatTheme" data-v="' + id + '" aria-pressed="' + (s.settings.chatTheme === id) + '" aria-label="' + n + ' chat theme"><i style="background:' + g + '"></i>' + n + '</button>').join('') + '</div>' +
      '<div class="set-row"><span class="ico">' + H.icon('eye', 18) + '</span><span class="txt"><b>Text size</b></span>' + seg('textSize', [['sm', 'Small'], ['md', 'Medium'], ['lg', 'Large']]) + '</div>' +
      C.switchRow('lowFx', 'sparkle', 'Lighter effects', 'Less blur and motion. Helps older phones and saves battery.', s.settings.lowFx) + '</div>' +

      '<div class="set-group glass"><h4>Notifications</h4>' +
      C.switchRow('notif.messages', 'bell', 'Message alerts', 'Show a banner when a new message arrives', s.settings.notif.messages) +
      C.switchRow('notif.sound', 'sparkle', 'Sound', 'Play a soft chime', s.settings.notif.sound) +
      C.switchRow('notif.preview', 'eye', 'Show previews', 'Include message text in alerts', s.settings.notif.preview) +
      C.switchRow('notif.desktop', 'phone', 'System notifications', 'When Halo is in the background (asks your browser for permission)', s.settings.notif.desktop, C.chipReal) + '</div>' +

      '<div class="set-group glass"><h4>Privacy</h4>' +
      C.switchRow('privacy.readReceipts', 'checks', 'Read receipts', remote ? 'Read status is always shared in online mode in this version' : 'Turn off to hide blue ticks. You also stop seeing theirs.', s.settings.privacy.readReceipts, sim()) +
      C.switchRow('privacy.lastSeen', 'clock', 'Last seen', 'Choose whether others see when you were last online', s.settings.privacy.lastSeen, sim()) + '</div>' +

      '<div class="set-group glass"><h4>Chats</h4>' +
      C.switchRow('enterToSend', 'send', 'Enter sends message', 'Off: Enter adds a new line, use the send button', s.settings.enterToSend) + '</div>' +

      (remote ? '<div class="set-group glass"><h4>Account</h4><button class="set-row" data-act="signout"><span class="ico">' + H.icon('lock', 18) + '</span><span class="txt"><b>Sign out</b></span></button></div>' : '') +
      '<p class="set-foot">Halo 1.0 · original design, no WhatsApp assets<br>Built with plain HTML, CSS and JavaScript</p>';
    const box = $('#tab-settings');
    if (box._h !== html) { box._h = html; box.innerHTML = html; }
  };

  S.themeSheet = () => {
    const sh = H.overlay.sheet({
      title: 'Chat theme',
      html: '<div class="swatches" style="padding:0;justify-content:center">' + THEMES.map(([id, n, g]) => '<button class="swatch" data-v="' + id + '" aria-pressed="' + (st().settings.chatTheme === id) + '" aria-label="' + n + '"><i style="background:' + g + '"></i>' + n + '</button>').join('') + '</div>',
      onMount(el) { el.addEventListener('click', (e) => { const b = e.target.closest('[data-v]'); if (b) { S.set('chatTheme', b.dataset.v); sh.close(); } }); }
    });
  };

  S.profileSheet = () => {
    const me = st().me; let avatar = me.avatar; let changed = false;
    const sh = H.overlay.sheet({
      title: 'Edit profile',
      html: '<div class="avatar-edit"><button class="av-wrap" id="pf-pick" aria-label="Change profile photo" style="position:relative;border-radius:50%"><span id="pf-av">' + C.avatar(me, 112) + '</span><span class="cam">' + H.icon('camera', 18) + '</span></button>' +
        '<button class="link-btn" id="pf-rm" ' + (me.avatar ? '' : 'hidden') + '>Remove photo</button><input type="file" id="pf-file" accept="image/*" hidden></div>' +
        '<label class="field"><span>Display name</span><input class="input" id="pf-name" maxlength="40" value="' + U.esc(me.name) + '" autocomplete="name"></label>' +
        '<label class="field"><span>About</span><input class="input" id="pf-about" maxlength="80" value="' + U.esc(me.about || '') + '"></label>' +
        (H.backend.mode === 'local' ? '<label class="field"><span>Phone</span><input class="input" id="pf-phone" maxlength="24" inputmode="tel" value="' + U.esc(me.phone || '') + '"></label>' : '') +
        '<button class="btn primary block" id="pf-save">Save changes</button>',
      onMount(el) {
        const redraw = () => { const t = Object.assign({}, me, { avatar, name: el.querySelector('#pf-name').value || me.name }); el.querySelector('#pf-av').innerHTML = C.avatar(t, 112); el.querySelector('#pf-rm').hidden = !avatar; };
        el.querySelector('#pf-pick').onclick = () => el.querySelector('#pf-file').click();
        el.querySelector('#pf-file').onchange = async (e) => {
          const f = e.target.files[0]; if (!f) return;
          try { avatar = H.backend.mode === 'local' ? await U.resizeImage(f, 320, 0.85) : await uploadAvatar(f); changed = true; redraw(); }
          catch (x) { H.overlay.toast(x.message || 'Could not use that photo'); }
        };
        el.querySelector('#pf-rm').onclick = () => { avatar = null; changed = true; redraw(); };
        el.querySelector('#pf-name').addEventListener('input', redraw);
        const save = async () => {
          const name = el.querySelector('#pf-name').value.trim();
          if (!name) { el.querySelector('#pf-name').focus(); return H.overlay.toast('Display name cannot be empty.'); }
          const patch = { name, about: el.querySelector('#pf-about').value.trim(), avatar };
          const ph = el.querySelector('#pf-phone'); if (ph) patch.phone = ph.value.trim();
          sh.close(); await H.backend.updateProfile(patch); H.overlay.toast('Profile updated');
        };
        el.querySelector('#pf-save').onclick = save;
        el.addEventListener('keydown', (e) => { if (e.key === 'Enter' && e.target.tagName === 'INPUT' && e.target.type !== 'file') save(); });
      }
    });
  };
  async function uploadAvatar(f) { const r = await H.backend.upload(f, 'image'); return r.src; }

  S.bind = () => {
    $('#tab-settings').addEventListener('click', async (e) => {
      const sg = e.target.closest('[data-seg]'); if (sg) return S.set(sg.dataset.seg, sg.dataset.v);
      const tg = e.target.closest('[data-toggle]');
      if (tg) {
        const k = tg.dataset.toggle; const on = !get(k);
        if (k === 'notif.desktop' && on) {
          const r = await H.notify.askDesktop();
          if (r !== 'granted') return H.overlay.toast(r === 'unsupported' ? 'This browser does not support system notifications.' : 'Permission was not granted. You can allow it in your browser settings.');
        }
        return S.set(k, on);
      }
      const a = e.target.closest('[data-act]'); if (!a) return;
      if (a.dataset.act === 'profile') S.profileSheet();
      else if (a.dataset.act === 'signout') { if (await H.overlay.confirm({ title: 'Sign out?', text: 'You will need to sign in again to see your chats.', ok: 'Sign out' })) { await H.backend.signOut(); H.nav.clearChat(); H.auth.show(); } }
    });
  };

  H.settings = S;
})(window.Halo = window.Halo || {});
