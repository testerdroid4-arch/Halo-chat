/* Halo — demo data. Everything here is fictional: names, numbers and chats are invented.
   Timestamps are generated relative to "now" so Today / Yesterday separators always look right. */
(function (H) {
  'use strict';
  const U = H.U;

  H.PAL = [
    ['#7cf7d4', '#1fb5a0'], ['#ffb48a', '#ff6b5e'], ['#c4b5fd', '#7c6cf2'], ['#8fd3ff', '#3b82f6'],
    ['#ffd36e', '#f59e0b'], ['#f9a8d4', '#ec4899'], ['#b6f07c', '#22a06b'], ['#cbd5e1', '#64748b']
  ];

  /* Tiny generated "photos" so image bubbles work without shipping binary assets. */
  function art(kind, a, b) {
    const head = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 440"><defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1">' +
      '<stop offset="0" stop-color="' + a + '"/><stop offset="1" stop-color="' + b + '"/></linearGradient></defs><rect width="640" height="440" fill="url(#g)"/>';
    let body = '';
    if (kind === 'peaks') {
      body = '<circle cx="470" cy="130" r="48" fill="#fff" opacity=".85"/>' +
        '<path d="M0 440V300l130-120 100 90 120-150 160 180 130-60v200z" fill="#0b1d3a" opacity=".55"/>' +
        '<path d="M0 440V350l160-90 120 80 140-100 220 120v80z" fill="#071326" opacity=".85"/>';
    } else if (kind === 'waves') {
      body = '<circle cx="150" cy="110" r="38" fill="#fff" opacity=".8"/>' +
        '<path d="M0 260c80-40 160 40 240 0s160-40 240 0 120 30 160 0v180H0z" fill="#06283d" opacity=".5"/>' +
        '<path d="M0 320c90-40 150 40 250 0s150-30 250 10 90 10 140-10v120H0z" fill="#031a2b" opacity=".75"/>';
    } else {
      body = '<circle cx="520" cy="90" r="30" fill="#fff" opacity=".8"/>' +
        '<g fill="#0a1020" opacity=".85"><rect x="40" y="220" width="70" height="220"/><rect x="120" y="170" width="90" height="270"/><rect x="220" y="250" width="60" height="190"/>' +
        '<rect x="290" y="140" width="100" height="300"/><rect x="400" y="230" width="80" height="210"/><rect x="490" y="190" width="100" height="250"/></g>' +
        '<g fill="#ffe9a8" opacity=".8"><rect x="305" y="165" width="12" height="12"/><rect x="335" y="165" width="12" height="12"/><rect x="305" y="205" width="12" height="12"/>' +
        '<rect x="140" y="195" width="12" height="12"/><rect x="170" y="235" width="12" height="12"/><rect x="510" y="215" width="12" height="12"/></g>';
    }
    return U.svgData(head + body + '</svg>');
  }
  H.art = art;

  function settings() {
    const coarse = !!(window.matchMedia && window.matchMedia('(pointer: coarse)').matches);
    return {
      theme: 'dark', chatTheme: 'aurora', textSize: 'md', lowFx: false, hidden: [], enterToSend: !coarse,
      notif: { messages: true, sound: true, preview: true, desktop: false },
      privacy: { readReceipts: true, lastSeen: true },
      recentEmoji: []
    };
  }

  function me() {
    return { id: 'me', name: 'Sam Rivera', about: 'Available', phone: '+977 9800 000 000', avatar: null, c1: '#7cf7d4', c2: '#1fb5a0' };
  }

  function empty() {
    return { v: 1, me: me(), contacts: [], chats: [], settings: settings() };
  }

  function create() {
    const now = Date.now();
    const D = 1440;
    const T = (agoMin) => now - agoMin * 60000;

    const msg = (from, text, ago, extra) => Object.assign(
      { id: U.uid('m'), from, type: 'text', text, ts: T(ago) },
      from === 'me' ? { status: 'read' } : {}, extra || {});
    const img = (from, ago, src, cap, extra) => msg(from, cap || '', ago, Object.assign({ type: 'image', src }, extra || {}));
    const file = (from, ago, name, size, extra) => msg(from, '', ago, Object.assign({ type: 'file', file: { name, size } }, extra || {}));
    const voice = (from, ago, dur, extra) => msg(from, '', ago, Object.assign({ type: 'voice', dur }, extra || {}));
    const R = (by, emoji) => ({ by, emoji });

    const contact = (id, name, about, phone, i, online, seenAgo) => ({
      id, name, about, phone, avatar: null, c1: H.PAL[i][0], c2: H.PAL[i][1], online, lastSeen: T(seenAgo)
    });

    const contacts = [
      contact('c_aarav', 'Aarav Mehta', 'Design lead. Night owl.', '+977 9800 000 101', 0, true, 0),
      contact('c_sofia', 'Sofia Marín', 'Coffee first, everything else later', '+34 600 000 102', 1, true, 0),
      contact('c_mina', 'Mina Tamang', 'Out hiking 🥾', '+977 9800 000 103', 2, false, 200),
      contact('c_rohan', 'Rohan Shrestha', 'Cricket, chai, repeat', '+977 9800 000 104', 3, true, 0),
      contact('c_priya', 'Priya Nair', 'Reading list: infinite', '+91 98000 00105', 5, false, 1100),
      contact('c_jonas', 'Jonas Weber', 'Shipping on Fridays', '+49 150 0000 0106', 6, true, 0),
      contact('c_amara', 'Amara Okafor', 'Market stall on Saturdays', '+234 800 000 0107', 4, false, 40),
      contact('c_leo', 'Leo Park', 'Making playlists nobody asked for', '+82 10 0000 0108', 7, false, 6 * D),
      contact('c_nora', 'Nora Hale', 'Away from keyboard', '+44 7700 000109', 2, false, 3 * D),
      contact('c_kabir', 'Kabir Singh', 'Hey there! I am using Halo.', '+91 98000 00110', 3, false, 9 * D)
    ];

    const chats = [
      { id: 'ch_aarav', contactId: 'c_aarav', pinned: true, muted: false, unread: 2, draft: '', messages: [
        msg('c_aarav', 'Morning! Have you seen the new onboarding flow?', 2 * D + 40),
        msg('me', 'Just opened it. The glass cards look great.', 2 * D + 32),
        msg('c_aarav', 'Right? Getting the blur to behave on Android took a week.', 2 * D + 28),
        msg('me', 'Can you send over the palette when you get a minute?', D + 25),
        file('c_aarav', D + 20, 'Halo-palette-v3.pdf', 248000),
        msg('me', 'Perfect, thank you 🙌', D + 18, { reactions: [R('c_aarav', '❤️')] }),
        msg('c_aarav', 'Standup moved to 10:30, FYI.', 95),
        msg('me', "Got it. I'll bring the retention numbers.", 90),
        msg('c_aarav', 'Quick question: ship dark theme first?', 12),
        msg('c_aarav', "I think it's the safer launch. People love it at night.", 9)
      ] },
      { id: 'ch_sofia', contactId: 'c_sofia', pinned: false, muted: false, unread: 0, draft: '', messages: [
        msg('c_sofia', 'Pokhara in November?? I found a lakeside place 👀', D + 500),
        msg('me', 'Yes please. Send photos!', D + 498),
        img('c_sofia', D + 490, art('peaks', '#ffb48a', '#4a3a8c'), 'View from the room'),
        msg('me', 'Okay, that is unreal.', D + 488),
        msg('c_sofia', 'Booking tonight unless you object', D + 485, { reactions: [R('me', '😍')] }),
        voice('c_sofia', 240, 23, { heard: true }),
        msg('me', 'Listened. Yes to the 7am boat ride, no to the 5am hike 😅', 236),
        msg('c_sofia', 'Deal. Confirmation coming through shortly.', 62)
      ] },
      { id: 'ch_rohan', contactId: 'c_rohan', pinned: true, muted: false, unread: 1, draft: '', messages: [
        msg('c_rohan', 'Cricket tonight? Ground opens at 6.', D + 30),
        msg('me', 'Count me in.', D + 29),
        msg('c_rohan', 'Bring the good bat this time 😂', D + 28),
        msg('me', 'No promises.', D + 27),
        msg('c_rohan', 'Teams are full, but I saved you a spot.', 30),
        msg('me', 'Perfect, see you at 6.', 25),
        msg('c_rohan', 'Also, you owe me chai ☕', 4)
      ] },
      { id: 'ch_jonas', contactId: 'c_jonas', pinned: false, muted: false, unread: 0, draft: '', messages: [
        msg('c_jonas', 'PR #482 is ready for another look.', D + 600),
        msg('me', 'Reviewing after lunch.', D + 590),
        msg('c_jonas', 'No rush. The tests are green.', D + 585),
        file('c_jonas', 380, 'coverage-report.html', 1480000),
        msg('me', 'Left two small comments, otherwise good to merge.', 340, { reactions: [R('c_jonas', '👍')] })
      ] },
      { id: 'ch_amara', contactId: 'c_amara', pinned: false, muted: true, unread: 3, draft: '', messages: [
        msg('c_amara', 'Did you get the invite for Friday?', 700),
        msg('me', 'Not yet. Can you resend?', 690),
        msg('c_amara', 'Sent! Check your spam folder too.', 120),
        msg('c_amara', 'Bring a friend if you like.', 118),
        msg('c_amara', 'Dress code: colourful 🎨', 117)
      ] },
      { id: 'ch_mina', contactId: 'c_mina', pinned: false, muted: false, unread: 0, draft: '', messages: [
        msg('me', 'Safe trails! Message me when you have signal.', 3 * D),
        msg('c_mina', 'Will do! Back on Sunday, the ridge is unreal.', 3 * D - 30),
        img('c_mina', 3 * D - 31, art('waves', '#7cf7d4', '#0f4c75'), 'Camp view'),
        msg('me', 'Photos when you are back?', 215, { status: 'delivered' })
      ] },
      { id: 'ch_priya', contactId: 'c_priya', pinned: false, muted: false, unread: 0, draft: '', messages: [
        msg('c_priya', 'Finished the book you lent me. That ending!', 2 * D + 120),
        msg('me', 'No spoilers!! I am on chapter 9.', 2 * D + 110),
        msg('c_priya', 'Fine, fine. Chapter 9 is where it gets good.', 2 * D + 100),
        msg('me', 'Okay now I am nervous 😄', 2 * D + 98),
        msg('c_priya', 'Lunch Saturday? I will bring it back.', D + 200),
        msg('me', 'Saturday works.', D + 195)
      ] },
      { id: 'ch_leo', contactId: 'c_leo', pinned: false, muted: false, unread: 0, draft: '', messages: [
        msg('c_leo', 'Made you a playlist for the train ride.', 6 * D + 60),
        img('c_leo', 6 * D + 59, art('city', '#f9a8d4', '#312e81'), 'Cover art, obviously'),
        msg('me', 'This is perfect. Thank you!', 6 * D + 20)
      ] }
    ];

    return { v: 1, me: me(), contacts, chats, settings: settings() };
  }

  /* Personas drive the simulated replies in js/services/backend.js. */
  H.personas = {
    c_aarav: {
      chat: ['Makes sense.', 'Let me sketch that out and send it over.', 'Ha, classic. Give me ten minutes.', 'Agreed. Ship it, polish later.', "I'll push the update after lunch."],
      answers: ["Honestly? I'd go with the simpler option.", 'Good question. I think yes, but let me double-check.', 'Probably, depends on the Android build. Checking now.'],
      nudges: ['Found a tiny alignment bug in the composer, fixing it now 🔧', 'Coffee run. Want anything?', 'New build is up if you want to test it on your phone.']
    },
    c_sofia: {
      chat: ['Love that ✨', 'Okay okay, I am convinced.', 'Sending you a map pin in a second.', 'This is going to be so good.'],
      answers: ['Yes! Definitely yes.', 'Hmm, let me check the dates and get back to you.', 'I would say go for it.'],
      nudges: ['The lake looks even better in person, look at this light 😍', 'Quick poll: pancakes or momo for breakfast?']
    },
    c_rohan: {
      chat: ['Haha fair.', 'See you at the ground.', 'Bring water, it is going to be hot.', 'Legend.'],
      answers: ['Obviously.', 'Not a chance 😂', 'Ask me after the match.'],
      nudges: ['Match is on in 30 minutes. Where are you?', 'Forgot my pads. Can you grab the spare ones?']
    },
    c_jonas: {
      chat: ['Thanks, merging now.', 'Noted. I will fix that in a follow-up.', 'Nice catch.'],
      answers: ['Yes, that should work.', 'I would keep it behind a flag for now.', 'Not yet, waiting on CI.'],
      nudges: ['Deploy went out. All green 🟢']
    },
    c_amara: { chat: ['Sounds good!', 'Perfect, see you then.'], answers: ['Yes, of course.'], nudges: [] },
    c_priya: { chat: ['Ha! Okay.', 'Sounds good.'], answers: ['Probably.'], nudges: [] },
    c_mina: { chat: ['Reception is patchy up here, but I got this!'], answers: ['Maybe!'], nudges: [] },
    c_leo: { chat: ['Nice.', 'Haha, thanks.'], answers: ['Sure!'], nudges: [] }
  };
  H.genericReplies = {
    chat: ['Got it 👍', 'Haha, nice.', 'Sounds good to me.', 'Okay! Let me think about it.', 'Totally.', 'Thanks for letting me know.'],
    answers: ['Yes, I think so.', 'Not sure yet. I will let you know.', 'Probably, yeah.'],
    greet: ['Hey! 👋', 'Hi there!', 'Hello! How is your day going?'],
    thanks: ['Anytime!', 'No problem 🙌', 'Happy to help.'],
    image: ['Wow, that is a great shot 😍', 'Love this!', 'Okay, that looks amazing.'],
    voice: ['Listening to this now 🎧', 'Got your voice note, one sec.'],
    file: ['Got it, thanks. Taking a look now.', 'Received 👍 I will read through it.']
  };

  H.seed = { create, empty, settings, me };
})(window.Halo = window.Halo || {});
