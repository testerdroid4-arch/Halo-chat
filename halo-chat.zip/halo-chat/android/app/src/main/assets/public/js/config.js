/* Halo — runtime configuration.
   With both values set, Halo runs online (sign-up, real-time chat, uploads) using your Supabase project.
   Clear both to fall back to the offline demo. The anon key is public by design; row-level security in
   backend/supabase/schema.sql is what protects the data. Never put a service_role key in this file. */
window.HALO_CONFIG = {
  supabaseUrl: 'https://fhxzezvpyqasibjqsgii.supabase.co',
  supabaseAnonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZoeHplenZweXFhc2lianFzZ2lpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTMwMTYyOTksImV4cCI6MjEwODU5MjI5OX0.n_Jj-vdyJaND2XGABL2X8GJzxSiwJD8N6I--d5BagMQ'
};
