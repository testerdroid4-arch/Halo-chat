/* Halo — SIMULATED backend (default).
   Implements the same interface as backend-supabase.js, but everything happens on this device:
   delivery ticks, read receipts, typing indicators and contact replies are scripted with timers.
   Nothing is sent over a network. Contacts are fictional personas (see data/seed.js). */
(function (H) {
  'use strict';
  const U = H.U;
  const S = () => H.store;
  const pending = {};
  let ambientCount = 0;
  let ambientTimer = null;

  function chatOf(id) { return S().get().chats.find((c) => c.id === id); }
  function contactOf(id) { return S().get().contacts.find((c) => c.id === id); }
  function msgOf(chat, id) { return chat && chat.messages.find((m) => m.id === id); }
  function viewing(chatId) { return H.session.openChat === chatId && document.visibilityState === 'visible'; }

  function pickReply(contactId, last) {
    const persona = H.personas[contactId] || {};
    const g = H.genericReplies;
    const pool = (k) => (persona[k] && persona[k].length ? persona[k] : g[k]);
    if (!last) return U.sample(pool('chat'));
    if (last.type === 'image') return U.sample(g.image);
    if (last.type === 'voice') return U.sample(g.voice);
    if (last.type === 'file') return U.sample(g.file);
    const t = last.text || '';
    if (/^(hi|hello|hey|yo|namaste|hola)\b/i.test(t)) return U.sample(g.greet);
    if (/thank|thx|cheers/i.test(t)) return U.sample(g.thanks);
    if (/\?\s*$/.test(t)) return U.sample(pool('answers'));
    return U.sample(pool('chat'));
  }

  function setStatus(chatId, ids, status) {
    S().commit((st) => {
      const c = st.chats.find((x) => x.id === chatId);
      if (!c) return;
      c.messages.forEach((m) => {
        if (ids.includes(m.id) && m.from === 'me' && rank(m.status) < rank(status)) m.status = status;
      });
    });
  }
  const rank = (s) => ({ failed: 0, sending: 1, sent: 2, delivered: 3, read: 4 }[s] || 0);

  function deliverIncoming(chatId, contactId, msg) {
    S().commit((st) => {
      const c = st.chats.find((x) => x.id === chatId);
      if (!c) return;
      c.typing = false;
      c.messages.push(msg);
      if (viewing(chatId)) c.unread = 0; else c.unread = (c.unread || 0) + 1;
    });
    H.notify.incoming(chatOf(chatId), contactOf(contactId), msg);
  }

  function typeThenSend(chatId, contactId, text, startDelay) {
    setTimeout(() => {
      const c = chatOf(chatId);
      if (!c) return;
      S().commit((st) => { st.chats.find((x) => x.id === chatId).typing = true; });
      const dur = Math.min(4200, 900 + text.length * 48);
      setTimeout(() => {
        deliverIncoming(chatId, contactId, { id: U.uid('m'), from: contactId, type: 'text', text, ts: Date.now() });
      }, dur);
    }, startDelay);
  }

  const Local = {
    mode: 'local',
    label: 'Simulated on this device',

    async init() {
      S().commit((st) => {
        st.chats.forEach((c) => {
          c.typing = false;
          c.messages.forEach((m) => { if (m.from === 'me' && (m.status === 'sending' || m.status === 'failed')) m.status = 'delivered'; });
        });
      }, true);
      Local.scheduleAmbient(25000);
      return { signedIn: true };
    },

    send(chatId, part) {
      const m = Object.assign({ id: U.uid('m'), from: 'me', type: 'text', text: '', ts: Date.now(), status: 'sending' }, part);
      S().commit((st) => {
        const c = st.chats.find((x) => x.id === chatId);
        c.messages.push(m);
        c.draft = '';
        c.unread = 0;
      });
      Local.simulate(chatId, m);
      return m;
    },

    simulate(chatId, m) {
      const chat = chatOf(chatId);
      const contact = contactOf(chat.contactId);
      const receipts = S().get().settings.privacy.readReceipts;
      setTimeout(() => setStatus(chatId, [m.id], 'sent'), 350);
      setTimeout(() => setStatus(chatId, [m.id], 'delivered'), 900 + Math.random() * 500);
      if (!contact.online) return; // offline contacts get the message but never answer

      if (!pending[chatId]) {
        pending[chatId] = true;
        const readAt = 1500 + Math.random() * 1200;
        setTimeout(() => {
          if (receipts) {
            const ids = chatOf(chatId).messages.filter((x) => x.from === 'me').map((x) => x.id);
            setStatus(chatId, ids, 'read');
          }
        }, readAt);
        setTimeout(() => {
          const c = chatOf(chatId);
          const last = c && [...c.messages].reverse().find((x) => x.from === 'me');
          const text = pickReply(contact.id, last);
          typeThenSend(chatId, contact.id, text, 0);
          setTimeout(() => { pending[chatId] = false; }, 800 + Math.min(4200, 900 + text.length * 48));
        }, readAt + 500);
      }

      // Now and then the contact reacts to what you sent.
      if (m.type !== 'voice' && Math.random() < 0.3) {
        setTimeout(() => {
          const c = chatOf(chatId); const mm = msgOf(c, m.id);
          if (!mm || mm.deleted) return;
          S().commit(() => { mm.reactions = (mm.reactions || []).filter((r) => r.by !== contact.id).concat({ by: contact.id, emoji: U.sample(['👍', '❤️', '😂']) }); });
        }, 3500 + Math.random() * 2500);
      }
    },

    react(chatId, msgId, emoji) {
      S().commit((st) => {
        const m = msgOf(st.chats.find((c) => c.id === chatId), msgId);
        if (!m || m.deleted) return;
        const mine = (m.reactions || []).find((r) => r.by === 'me');
        m.reactions = (m.reactions || []).filter((r) => r.by !== 'me');
        if (!mine || mine.emoji !== emoji) m.reactions.push({ by: 'me', emoji });
      });
    },

    remove(chatId, msgId, forEveryone) {
      S().commit((st) => {
        const c = st.chats.find((x) => x.id === chatId);
        const i = c.messages.findIndex((m) => m.id === msgId);
        if (i < 0) return;
        if (forEveryone && c.messages[i].from === 'me') {
          const m = c.messages[i];
          m.deleted = true; m.text = ''; m.reactions = [];
          delete m.src; delete m.file; delete m.audio; delete m.replyTo;
        } else c.messages.splice(i, 1);
      });
    },

    markRead(chatId) {
      const c = chatOf(chatId);
      if (c && c.unread) S().commit((st) => { st.chats.find((x) => x.id === chatId).unread = 0; });
    },

    markUnread(chatId) { S().commit((st) => { const c = st.chats.find((x) => x.id === chatId); if (c) c.unread = Math.max(1, c.unread || 0); }); },
    setTyping() { /* the simulated contacts do not see your typing */ },
    setDraft(chatId, text) { S().commit((st) => { const c = st.chats.find((x) => x.id === chatId); if (c) c.draft = text; }, true); },

    startChat(contactId) {
      let c = S().get().chats.find((x) => x.contactId === contactId);
      if (c) return c.id;
      c = { id: U.uid('ch'), contactId, pinned: false, muted: false, unread: 0, draft: '', messages: [] };
      S().commit((st) => { st.chats.unshift(c); });
      return c.id;
    },

    clearChat(chatId) { S().commit((st) => { const c = st.chats.find((x) => x.id === chatId); if (c) { c.messages = []; c.unread = 0; } }); },
    deleteChat(chatId) { S().commit((st) => { st.chats = st.chats.filter((x) => x.id !== chatId); }); },
    patchChat(chatId, patch) { S().commit((st) => { Object.assign(st.chats.find((x) => x.id === chatId), patch); }); },

    addContact(name, phone) {
      const i = S().get().contacts.length % H.PAL.length;
      const c = { id: U.uid('c'), name, about: 'Hey there! I am using Halo.', phone: phone || '', avatar: null, c1: H.PAL[i][0], c2: H.PAL[i][1], online: false, lastSeen: Date.now() - 3600000 };
      S().commit((st) => { st.contacts.push(c); });
      return c.id;
    },

    updateProfile(patch) { S().commit((st) => { Object.assign(st.me, patch); }); return Promise.resolve(); },

    /* Images become small JPEG data URLs; other files keep only their name and size. */
    async upload(file, kind) {
      if (kind === 'image') return { src: await U.resizeImage(file, 1100, 0.78) };
      if (kind === 'voice') {
        if (file.size > 420000) return {};
        return { audio: await new Promise((res) => { const r = new FileReader(); r.onload = () => res(r.result); r.readAsDataURL(file); }) };
      }
      return {};
    },

    /* Contacts occasionally message first so the demo feels alive. */
    scheduleAmbient(delay) {
      clearTimeout(ambientTimer);
      ambientTimer = setTimeout(() => {
        Local.ambient();
        if (ambientCount < 5) Local.scheduleAmbient(60000 + Math.random() * 60000);
      }, delay);
    },
    ambient() {
      if (document.hidden) return;
      const st = S().get();
      const pool = st.chats.filter((c) => {
        const ct = contactOf(c.contactId);
        const p = H.personas[c.contactId];
        return ct && ct.online && p && p.nudges && p.nudges.length && H.session.openChat !== c.id && !c.typing;
      });
      if (!pool.length) return;
      const c = U.sample(pool);
      ambientCount++;
      typeThenSend(c.id, c.contactId, U.sample(H.personas[c.contactId].nudges), 100);
    }
  };

  H.backendLocal = Local;
})(window.Halo = window.Halo || {});
