/* Halo — overlay layer: toasts, notification banner, bottom sheets / modals, context menu, confirm, lightbox. */
(function (H) {
  'use strict';
  const U = H.U;
  const stack = []; // open closable layers, topmost last
  let toastBox = null;

  function root() { return document.getElementById('overlays'); }
  function el(html) { const t = document.createElement('div'); t.innerHTML = html.trim(); return t.firstElementChild; }

  const O = {};

  O.toast = (text, opts = {}) => {
    if (!toastBox) { toastBox = el('<div class="toasts" role="status" aria-live="polite"></div>'); root().appendChild(toastBox); }
    const t = el('<div class="toast glass"><span>' + U.esc(text) + '</span>' + (opts.action ? '<button>' + U.esc(opts.action.label) + '</button>' : '') + '</div>');
    if (opts.action) t.querySelector('button').onclick = () => { opts.action.fn(); kill(); };
    toastBox.appendChild(t);
    const kill = () => { t.classList.add('out'); setTimeout(() => t.remove(), 250); };
    setTimeout(kill, opts.ms || 3200);
  };

  O.banner = ({ contact, body, chatId }) => {
    const old = root().querySelector('.banner'); if (old) old.remove();
    const b = el('<button class="banner glass" aria-label="Open chat with ' + U.esc(contact.name) + '">' + H.C.avatar(contact, 42) +
      '<span class="bt"><b>' + U.esc(contact.name) + '</b><span>' + U.esc(body) + '</span></span></button>');
    b.onclick = () => { b.remove(); H.nav.openChat(chatId); };
    root().appendChild(b);
    setTimeout(() => { b.classList.add('out'); setTimeout(() => b.remove(), 300); }, 4200);
  };

  function closeLayer(layer) {
    const i = stack.indexOf(layer); if (i < 0) return;
    stack.splice(i, 1);
    layer.nodes.forEach((n) => n.classList.add('out'));
    setTimeout(() => layer.nodes.forEach((n) => n.remove()), 260);
    if (layer.onClose) layer.onClose();
    if (layer.prevFocus && layer.prevFocus.focus) { try { layer.prevFocus.focus({ preventScroll: true }); } catch (e) { /* ignore */ } }
  }
  O.closeTop = () => { if (stack.length) { closeLayer(stack[stack.length - 1]); return true; } return false; };
  O.closeAll = () => { while (stack.length) closeLayer(stack[stack.length - 1]); };

  O.sheet = ({ title, html, flush, onMount, onClose }) => {
    const scrim = el('<div class="scrim"></div>');
    const sh = el('<div class="sheet glass" role="dialog" aria-modal="true" aria-label="' + U.esc(title || 'Dialog') + '"><div class="grab"></div>' +
      (title ? '<div class="sheet-head"><h3>' + U.esc(title) + '</h3><button class="icon-btn" data-close aria-label="Close">' + H.icon('x', 20) + '</button></div>' : '') +
      '<div class="sheet-body' + (flush ? ' flush' : '') + '">' + html + '</div></div>');
    const layer = { nodes: [scrim, sh], onClose, prevFocus: document.activeElement };
    scrim.onclick = () => closeLayer(layer);
    sh.addEventListener('click', (e) => { if (e.target.closest('[data-close]')) closeLayer(layer); });
    root().append(scrim, sh);
    stack.push(layer);
    const focusable = sh.querySelector('input, textarea, [data-autofocus]');
    if (focusable && !window.matchMedia('(pointer: coarse)').matches) focusable.focus();
    if (onMount) onMount(sh, () => closeLayer(layer));
    return { el: sh, close: () => closeLayer(layer) };
  };

  /* Context menu anchored to a point (x, y) or a DOMRect. */
  O.menu = ({ x, y, rect, quick, mine, items, onQuick }) => {
    const scrim = el('<div class="scrim" style="background:transparent;backdrop-filter:none;-webkit-backdrop-filter:none"></div>');
    const m = el('<div class="menu glass" role="menu"></div>');
    let h = '';
    if (quick) h += '<div class="quick">' + quick.map((e) => '<button role="menuitem" data-q="' + e + '" class="' + (e === mine ? 'mine' : '') + '" aria-label="React ' + e + '">' + e + '</button>').join('') + '</div>';
    h += items.filter(Boolean).map((it, i) => '<button class="item ' + (it.danger ? 'danger' : '') + '" role="menuitem" data-i="' + i + '">' + H.icon(it.icon, 18) + '<span>' + U.esc(it.label) + '</span></button>').join('');
    m.innerHTML = h;
    const layer = { nodes: [scrim, m], prevFocus: document.activeElement };
    const list = items.filter(Boolean);
    m.addEventListener('click', (e) => {
      const q = e.target.closest('[data-q]');
      if (q) { closeLayer(layer); onQuick && onQuick(q.dataset.q); return; }
      const it = e.target.closest('[data-i]');
      if (it) { closeLayer(layer); list[+it.dataset.i].fn(); }
    });
    // A phone's own long-press "contextmenu" event arrives ~100ms after we open the menu and lands on
    // this scrim. Ignore taps/contextmenu events that arrive right after opening, or the menu vanishes.
    const born = Date.now();
    scrim.onclick = () => { if (Date.now() - born > 450) closeLayer(layer); };
    scrim.oncontextmenu = (e) => { e.preventDefault(); if (Date.now() - born > 900) closeLayer(layer); };
    root().append(scrim, m);
    stack.push(layer);
    const vw = window.innerWidth, vh = window.innerHeight;
    const w = m.offsetWidth, hh = m.offsetHeight;
    const ax = rect ? rect.left + rect.width / 2 : x;
    let left = Math.min(Math.max(10, ax - w / 2), vw - w - 10);
    if (!rect && x != null) left = Math.min(Math.max(10, x - w / 2), vw - w - 10);
    let top = rect ? rect.bottom + 8 : y + 6;
    if (top + hh > vh - 10) top = Math.max(10, (rect ? rect.top - 8 : y - 6) - hh);
    m.style.left = left + 'px'; m.style.top = top + 'px';
    m.style.setProperty('--ox', (ax - left) + 'px');
    m.style.setProperty('--oy', top > (rect ? rect.top : y) ? '0%' : '100%');
    const first = m.querySelector('.item'); if (first && !quick) first.focus({ preventScroll: true });
    return layer;
  };

  O.confirm = ({ title, text, ok = 'Confirm', danger, extra }) => new Promise((resolve) => {
    let done = false;
    const s = O.sheet({
      title,
      html: '<p style="color:var(--fg2)">' + U.esc(text || '') + '</p><div class="sheet-actions">' +
        (extra ? '<button class="btn danger" data-x>' + U.esc(extra) + '</button>' : '') +
        '<button class="btn" data-no>Cancel</button><button class="btn ' + (danger ? 'danger' : 'primary') + '" data-yes>' + U.esc(ok) + '</button></div>',
      onClose: () => { if (!done) { done = true; resolve(false); } }
    });
    s.el.querySelector('[data-yes]').onclick = () => { done = true; s.close(); resolve(true); };
    s.el.querySelector('[data-no]').onclick = () => s.close();
    const x = s.el.querySelector('[data-x]');
    if (x) x.onclick = () => { done = true; s.close(); resolve('extra'); };
  });

  O.lightbox = (src) => {
    const lb = el('<div class="lightbox" role="dialog" aria-label="Photo"><img alt="Photo preview" src="' + U.esc(src) + '"><button class="icon-btn" aria-label="Close">' + H.icon('x', 22) + '</button></div>');
    const layer = { nodes: [lb], prevFocus: document.activeElement };
    lb.onclick = () => closeLayer(layer);
    root().appendChild(lb); stack.push(layer);
  };

  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && O.closeTop()) e.preventDefault(); });
  H.overlay = O;
})(window.Halo = window.Halo || {});
