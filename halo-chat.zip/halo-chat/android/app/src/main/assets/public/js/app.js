/* Halo — boot sequence, theming and hash-based navigation (so the Android back button works). */
(function (H) {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const mqDark = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : { matches: true, addEventListener() {} };
  const mqDesktop = window.matchMedia ? window.matchMedia('(min-width: 900px)') : { matches: false };

  H.session = { openChat: null, tab: 'chats', filter: 'all', q: '' };

  H.applyTheme = () => {
    const s = H.store.get().settings; const r = document.documentElement;
    const dark = s.theme === 'system' ? mqDark.matches : s.theme !== 'light';
    r.dataset.theme = dark ? 'dark' : 'light';
    r.dataset.chattheme = s.chatTheme || 'aurora';
    r.dataset.text = s.textSize || 'md';
    const low = s.lowFx || (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
    r.dataset.fx = low ? 'low' : 'high';
    const m = document.querySelector('meta[name="theme-color"]'); if (m) m.content = dark ? '#060a14' : '#e4edfa';
    try { const sb = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.SystemBars; if (sb) sb.setStyle({ style: dark ? 'DARK' : 'LIGHT' }); } catch (e) { /* not running in the Android app */ }
  };

  /* ----- navigation: only the open chat lives in the URL hash ----- */
  let pushed = false;
  const inChatHash = () => /^#chat\//.test(location.hash);
  H.nav = {
    openChat(id) {
      if (inChatHash()) { history.replaceState(null, '', '#chat/' + id); route(); }
      else { pushed = true; location.hash = '#chat/' + id; }
    },
    back() {
      if (!inChatHash()) return route();
      if (pushed) { pushed = false; history.back(); }
      else { history.replaceState(null, '', location.pathname + location.search); route(); }
    },
    clearChat() { history.replaceState(null, '', location.pathname + location.search); route(); }
  };

  function route() {
    const app = $('#app');
    const m = /^#chat\/(.+)$/.exec(location.hash);
    const id = m && decodeURIComponent(m[1]);
    if (id && H.store.chat(id)) {
      H.session.openChat = id; app.dataset.view = 'chat';
      H.chatView.open(id);
      $('.main').removeAttribute('inert');
    } else {
      if (H.session.openChat) H.chatView.close();
      H.session.openChat = null; app.dataset.view = 'list';
      if (!mqDesktop.matches) $('.main').setAttribute('inert', '');
      if (id) history.replaceState(null, '', location.pathname + location.search);
    }
    H.lists.renderChats();
  }

  function onState() {
    H.applyTheme();
    H.lists.renderTop();
    H.lists.renderAll();
    H.chatView.update();
  }

  function mountError(msg) {
    const d = document.createElement('div'); d.className = 'auth';
    d.innerHTML = '<div class="auth-card glass"><div class="brand">' + H.logo(40) + 'Halo</div><p class="lead">' + H.U.esc(msg) + '</p>' +
      '<button class="btn primary block" id="demo-go">Continue with the offline demo</button></div>';
    $('#overlays').appendChild(d);
    return new Promise((res) => { d.querySelector('#demo-go').onclick = () => { d.remove(); res(); }; });
  }

  function hideBoot() { const b = $('#boot'); if (!b) return; b.classList.add('out'); setTimeout(() => b.remove(), 600); }

  /* Sending a message to an archived chat brings it back to the main list (like WhatsApp). */
  function wrapBackend(b) {
    if (b._wrapped) return; b._wrapped = true;
    const send = b.send;
    b.send = function (chatId) {
      const c = H.store.chat(chatId);
      if (c && c.archived) b.patchChat(chatId, { archived: false });
      return send.apply(this, arguments);
    };
  }

  async function boot() {
    let remote = H.backendSupabase.configured();
    H.store.init(remote);
    H.backend = remote ? H.backendSupabase : H.backendLocal;
    wrapBackend(H.backendSupabase); wrapBackend(H.backendLocal);
    H.applyTheme();

    H.lists.bind(); H.chatView.bind(); H.settings.bind();
    H.store.on(onState);
    mqDark.addEventListener && mqDark.addEventListener('change', H.applyTheme);
    window.addEventListener('hashchange', route);
    window.addEventListener('keydown', (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); H.lists.showTab('chats'); $('#search-input').focus(); }
    });

    let state;
    try { state = await H.backend.init(); if (!state.signedIn) { H.lists.showTab('chats'); hideBoot(); await H.auth.show(); } }
    catch (err) {
      hideBoot();
      await mountError('Could not reach the online backend (' + (err.message || 'unknown error') + '). You can keep exploring with the offline demo.');
      remote = false; H.store.init(false); H.backend = H.backendLocal; await H.backend.init();
    }

    H.lists.showTab('chats');
    onState();
    route();
    // On desktop, open the most recent chat so the screen is never empty on first load.
    if (mqDesktop.matches && !H.session.openChat) {
      const first = [...H.store.get().chats].sort((a, b) => ((b.messages.slice(-1)[0] || {}).ts || 0) - ((a.messages.slice(-1)[0] || {}).ts || 0))[0];
      if (first) { history.replaceState(null, '', '#chat/' + first.id); route(); }
    }
    hideBoot();
  }

  document.addEventListener('DOMContentLoaded', () => { boot().catch((e) => { console.error(e); const b = $('#boot'); if (b) b.innerHTML = '<p style="padding:24px;color:#fff">Halo could not start: ' + H.U.esc(e.message) + '</p>'; }); });
})(window.Halo = window.Halo || {});
