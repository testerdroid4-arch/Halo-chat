/* Halo — incoming-message alerts: in-app banner, soft chime and (optional) desktop notification.
   Honours the per-chat mute switch and the notification preferences in Settings. */
(function (H) {
  'use strict';
  let ctx = null;

  function chime() {
    try {
      ctx = ctx || new (window.AudioContext || window.webkitAudioContext)();
      if (ctx.state === 'suspended') ctx.resume();
      const t = ctx.currentTime;
      [[740, 0], [988, 0.09]].forEach(([f, d]) => {
        const o = ctx.createOscillator(), g = ctx.createGain();
        o.type = 'sine'; o.frequency.value = f;
        g.gain.setValueAtTime(0.0001, t + d);
        g.gain.exponentialRampToValueAtTime(0.07, t + d + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, t + d + 0.28);
        o.connect(g); g.connect(ctx.destination); o.start(t + d); o.stop(t + d + 0.3);
      });
    } catch (e) { /* audio is optional */ }
  }

  H.notify = {
    chime,
    incoming(chat, contact, msg) {
      const st = H.store.get();
      if (!st.settings.notif.messages || chat.muted) return;
      const viewing = H.session.openChat === chat.id && document.visibilityState === 'visible';
      if (viewing) return;
      if (st.settings.notif.sound) chime();
      const body = st.settings.notif.preview ? H.notify.preview(msg) : 'New message';
      if (document.visibilityState === 'visible') {
        H.overlay.banner({ contact, body, chatId: chat.id });
      } else if (st.settings.notif.desktop && 'Notification' in window && Notification.permission === 'granted') {
        try { new Notification(contact.name, { body, tag: chat.id }); } catch (e) { /* ignore */ }
      }
    },
    preview(m) {
      if (!m) return '';
      if (m.deleted) return 'This message was deleted';
      if (m.type === 'image') return '📷 ' + (m.text || 'Photo');
      if (m.type === 'voice') return '🎤 Voice message';
      if (m.type === 'file') return '📄 ' + (m.file ? m.file.name : 'File');
      return m.text;
    },
    async askDesktop() {
      if (!('Notification' in window)) return 'unsupported';
      if (Notification.permission === 'granted') return 'granted';
      try { return await Notification.requestPermission(); } catch (e) { return 'denied'; }
    }
  };
})(window.Halo = window.Halo || {});
