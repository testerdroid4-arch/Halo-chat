/* Halo — small reusable view helpers (return HTML strings). */
(function (H) {
  'use strict';
  const U = H.U;
  const C = {};

  C.avatar = (who, size = 48, online = false) => {
    const inner = who.avatar
      ? '<img src="' + U.esc(who.avatar) + '" alt="" loading="lazy" draggable="false">'
      : U.esc(U.initials(who.name));
    return '<span class="av" style="--s:' + size + 'px;--c1:' + (who.c1 || '#7cf7d4') + ';--c2:' + (who.c2 || '#1fb5a0') + '">' + inner +
      (online ? '<span class="dot" title="Online"></span>' : '') + '</span>';
  };

  /* Delivery ticks for outgoing messages. */
  C.tick = (status) => {
    if (status === 'sending') return '<span class="tick" title="Sending">' + H.icon('clock', 13) + '</span>';
    if (status === 'failed') return '<span class="tick failed" title="Not sent">' + H.icon('info', 14) + '</span>';
    if (status === 'sent') return '<span class="tick" title="Sent">' + H.icon('check', 14) + '</span>';
    if (status === 'delivered') return '<span class="tick" title="Delivered">' + H.icon('checks', 16) + '</span>';
    return '<span class="tick read" title="Read">' + H.icon('checks', 16) + '</span>';
  };

  C.switchRow = (id, icon, title, sub, on, chip) =>
    '<div class="set-row"><span class="ico">' + H.icon(icon, 18) + '</span><span class="txt"><b>' + U.esc(title) + (chip || '') + '</b>' +
    (sub ? '<small>' + U.esc(sub) + '</small>' : '') + '</span>' +
    '<button class="switch" role="switch" aria-checked="' + (on ? 'true' : 'false') + '" aria-label="' + U.esc(title) + '" data-toggle="' + id + '"></button></div>';

  C.chipSim = '<span class="chip sim" title="Stored on this device only. Nothing is sent to other people.">Simulated</span>';
  C.chipReal = '<span class="chip real">Live</span>';

  C.empty = (icon, title, text) =>
    '<div class="empty">' + H.icon(icon, 44) + '<h3>' + U.esc(title) + '</h3><p>' + U.esc(text) + '</p></div>';

  /* Auto-link plain URLs and enlarge messages made only of 1–3 emoji. Input must be raw text. */
  const EMOJI_ONLY = /^(?:\p{Extended_Pictographic}|\p{Emoji_Modifier}|‍|️|\s){1,12}$/u;
  C.richText = (raw, q, curHit) => {
    const text = String(raw || '');
    let out;
    const lone = EMOJI_ONLY.test(text) && (text.match(/\p{Extended_Pictographic}/gu) || []).length <= 3 && text.trim();
    if (lone) return '<span class="big">' + U.esc(text) + '</span>';
    const parts = text.split(/(https?:\/\/[^\s<]+)/g);
    out = parts.map((p, i) => {
      if (i % 2) return '<a href="' + U.esc(p) + '" target="_blank" rel="noopener noreferrer">' + hi(p, q) + '</a>';
      return hi(p, q);
    }).join('');
    return out;
  };
  function hi(s, q) {
    if (!q) return U.esc(s);
    const re = new RegExp('(' + U.escRe(q) + ')', 'ig');
    return s.split(re).map((p, i) => (i % 2 ? '<mark>' + U.esc(p) + '</mark>' : U.esc(p))).join('');
  }
  C.hi = hi;

  C.waveBars = (id, n = 34) => {
    let h = 7;
    for (let i = 0; i < id.length; i++) h = (h * 33 + id.charCodeAt(i)) >>> 0;
    let out = '';
    for (let i = 0; i < n; i++) {
      h = (h * 1664525 + 1013904223) >>> 0;
      out += '<i style="--h:' + (22 + (h % 78)) + '%"></i>';
    }
    return out;
  };
  C.mmss = (s) => Math.floor(s / 60) + ':' + U.pad(Math.floor(s % 60));

  H.C = C;
})(window.Halo = window.Halo || {});
