/* Halo — application state + persistence.
   One plain-object state tree, saved to localStorage (debounced). The UI reads it and calls
   `commit(fn)` to change it; subscribers (the UI) are told to re-render. In "remote" mode
   (Supabase) only your settings stay local — the server is the source of truth for chats. */
(function (H) {
  'use strict';
  const KEY = 'halo.v1';
  let state = null;
  let remote = false;
  const subs = [];
  let timer = null;

  const Store = {
    init(isRemote) {
      remote = !!isRemote;
      let saved = null;
      try { saved = JSON.parse(localStorage.getItem(KEY)); } catch (e) { saved = null; }
      if (remote) {
        const base = H.seed.empty();
        state = Object.assign(base, saved && saved.settings ? { settings: saved.settings } : {});
      } else if (saved && saved.v === 1 && saved.me && Array.isArray(saved.chats)) {
        state = saved;
        state.settings = Object.assign(H.seed.settings(), state.settings || {});
      } else {
        state = H.seed.create();
      }
      Store.flush();
      window.addEventListener('pagehide', Store.flush);
      return state;
    },
    get() { return state; },
    commit(fn, silent) {
      fn(state);
      Store.save();
      if (!silent) subs.forEach((f) => f(state));
    },
    on(f) { subs.push(f); },
    save() { clearTimeout(timer); timer = setTimeout(Store.flush, 250); },
    flush() {
      clearTimeout(timer);
      try {
        const out = remote ? { v: 1, me: state.me, settings: state.settings, contacts: [], chats: [] } : state;
        localStorage.setItem(KEY, JSON.stringify(out));
      } catch (e) {
        if (H.overlay) H.overlay.toast('Storage is full. Remove a few photos to keep saving.');
      }
    },
    replace(next) { state = next; Store.save(); subs.forEach((f) => f(state)); },
    reset() { state = remote ? H.seed.empty() : H.seed.create(); Store.flush(); subs.forEach((f) => f(state)); },
    bytes() { try { return (localStorage.getItem(KEY) || '').length * 2; } catch (e) { return 0; } },
    exportJSON() { return JSON.stringify(state, null, 2); },
    chat(id) { return state.chats.find((c) => c.id === id); },
    contact(id) { return state.contacts.find((c) => c.id === id); }
  };

  H.store = Store;
})(window.Halo = window.Halo || {});
