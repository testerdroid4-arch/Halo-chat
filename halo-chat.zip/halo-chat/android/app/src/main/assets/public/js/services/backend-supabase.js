/* Halo — ONLINE backend adapter for Supabase (auth, Postgres, Realtime, Storage).
   Same interface as backend-local.js. It is only used when js/config.js holds a project URL
   and anon key, and the SQL in backend/supabase/schema.sql has been run.
   NOTE: written against the supabase-js v2 API but not exercised against a live project in this build. */
(function (H) {
  'use strict';
  const U = H.U;
  const S = () => H.store;
  const SDK = 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/dist/umd/supabase.js';

  const SB = { mode: 'supabase', label: 'Online (Supabase)', directory: true, found: {}, client: null, uid: null, typingChannels: {}, typingTimers: {}, hb: null };

  SB.configured = () => { const c = window.HALO_CONFIG || {}; return !!(c.supabaseUrl && c.supabaseAnonKey); };

  const colorFor = (id) => { let h = 0; for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0; return H.PAL[h % H.PAL.length]; };
  const ts = (v) => (v ? new Date(v).getTime() : 0);
  const asMe = (id) => (id === SB.uid ? 'me' : id);
  const toDb = (id) => (id === 'me' ? SB.uid : id);

  function contactFrom(p) {
    const [c1, c2] = colorFor(p.id);
    return { id: p.id, name: p.display_name || 'Unknown', about: p.about || '', phone: '', avatar: p.avatar_url || null, c1, c2,
      online: !!p.last_seen && Date.now() - ts(p.last_seen) < 90000, lastSeen: ts(p.last_seen) };
  }
  function msgFrom(r) {
    const m = { id: r.id, from: asMe(r.sender_id), type: r.kind, text: r.body || '', ts: ts(r.created_at),
      reactions: (r.reactions || []).map((x) => ({ by: asMe(x.by), emoji: x.emoji })) };
    if (m.from === 'me') m.status = r.status || 'sent';
    if (r.reply_to) m.replyTo = r.reply_to;
    if (r.deleted) { m.deleted = true; m.text = ''; }
    if (r.kind === 'image') m.src = r.media_url;
    if (r.kind === 'file') m.file = { name: r.file_name, size: r.file_size || 0, url: r.media_url };
    if (r.kind === 'voice') { m.dur = r.duration || 0; m.audio = r.media_url; }
    return m;
  }

  SB.loadSdk = () => new Promise((res, rej) => {
    if (window.supabase) return res();
    const s = document.createElement('script');
    s.src = SDK; s.onload = res;
    s.onerror = () => rej(new Error('Could not load the Supabase SDK. Check your connection.'));
    document.head.appendChild(s);
  });

  SB.init = async function () {
    await SB.loadSdk();
    const c = window.HALO_CONFIG;
    SB.client = window.supabase.createClient(c.supabaseUrl, c.supabaseAnonKey, { auth: { persistSession: true, autoRefreshToken: true } });
    const { data } = await SB.client.auth.getSession();
    if (data.session) { await SB.afterAuth(data.session.user); return { signedIn: true }; }
    return { signedIn: false };
  };

  SB.signUp = async function (email, password, name) {
    const { data, error } = await SB.client.auth.signUp({ email, password, options: { data: { display_name: name } } });
    if (error) throw error;
    if (!data.session) return { signedIn: false, needsConfirm: true };
    await SB.afterAuth(data.user);
    return { signedIn: true };
  };
  SB.signIn = async function (email, password) {
    const { data, error } = await SB.client.auth.signInWithPassword({ email, password });
    if (error) throw error;
    await SB.afterAuth(data.user);
    return { signedIn: true };
  };
  SB.signOut = async function () {
    clearInterval(SB.hb);
    try { await SB.client.auth.signOut(); } catch (e) { /* ignore */ }
    S().reset();
  };

  SB.afterAuth = async function (user) {
    SB.uid = user.id;
    await SB.loadAll();
    SB.subscribe();
    SB.heartbeat();
    clearInterval(SB.hb);
    SB.hb = setInterval(SB.heartbeat, 45000);
  };

  SB.heartbeat = () => SB.client.from('profiles').update({ last_seen: new Date().toISOString() }).eq('id', SB.uid).then(() => {});

  SB.loadAll = async function () {
    const [pr, cv, ms] = await Promise.all([
      SB.client.from('profiles').select('id,display_name,about,avatar_url,last_seen'),
      SB.client.from('conversations').select('*'),
      SB.client.from('messages').select('*').order('created_at', { ascending: false }).limit(1000)
    ]);
    const err = pr.error || cv.error || ms.error;
    if (err) throw err;
    const hidden = S().get().settings.hidden || [];
    const meRow = pr.data.find((p) => p.id === SB.uid);
    const base = H.seed.empty();
    const [c1, c2] = colorFor(SB.uid);
    const me = Object.assign(base.me, { id: 'me', name: (meRow && meRow.display_name) || 'Me', about: (meRow && meRow.about) || '', avatar: meRow && meRow.avatar_url, phone: '', c1, c2 });
    // Only people you already have a conversation with are kept as contacts. Everyone else is found by search.
    const partners = new Set(cv.data.map((x) => (x.user_a === SB.uid ? x.user_b : x.user_a)));
    const contacts = pr.data.filter((p) => p.id !== SB.uid && partners.has(p.id)).map(contactFrom);
    const prefs = S().get().settings.chatPrefs || {};
    const chats = cv.data.map((cv1) => {
      const other = cv1.user_a === SB.uid ? cv1.user_b : cv1.user_a;
      const mine = ms.data.filter((r) => r.conversation_id === cv1.id && !hidden.includes(r.id)).reverse().map(msgFrom);
      const prev = (S().get().chats || []).find((x) => x.id === cv1.id) || {};
      const pf = prefs[cv1.id] || {};
      return { id: cv1.id, contactId: other, pinned: !!pf.pinned, muted: !!pf.muted, archived: !!pf.archived, draft: prev.draft || '', typing: false, messages: mine,
        unread: mine.filter((m) => m.from !== 'me' && !m.deleted && m.unreadRemote !== false && rowStatus(ms.data, m.id) !== 'read').length };
    });
    S().commit((st) => { st.me = me; st.contacts = contacts; st.chats = chats; });
  };
  const rowStatus = (rows, id) => { const r = rows.find((x) => x.id === id); return r && r.status; };

  SB.subscribe = function () {
    if (SB.rt) SB.client.removeChannel(SB.rt);
    SB.rt = SB.client.channel('halo-db')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, (p) => SB.onInsert(p.new))
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'messages' }, (p) => SB.onUpdate(p.new))
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'conversations' }, () => SB.loadAll())
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'profiles' }, (p) => SB.onProfile(p.new))
      .subscribe();
  };

  SB.onInsert = function (r) {
    const chat = S().get().chats.find((c) => c.id === r.conversation_id);
    if (!chat) { SB.loadAll(); return; }
    const exists = chat.messages.find((m) => m.id === r.id);
    const m = msgFrom(r);
    S().commit((st) => {
      const c = st.chats.find((x) => x.id === r.conversation_id);
      if (exists) { Object.assign(c.messages.find((x) => x.id === r.id), { status: m.status }); return; }
      c.typing = false;
      c.messages.push(m);
      if (m.from !== 'me') {
        if (H.session.openChat === c.id && document.visibilityState === 'visible') c.unread = 0; else c.unread = (c.unread || 0) + 1;
      }
    });
    if (!exists && m.from !== 'me') {
      SB.client.from('messages').update({ status: H.session.openChat === chat.id ? 'read' : 'delivered' }).eq('id', r.id).in('status', ['sent', 'delivered']).then(() => {});
      H.notify.incoming(S().get().chats.find((c) => c.id === chat.id), S().get().contacts.find((c) => c.id === chat.contactId), m);
    }
  };
  SB.onUpdate = function (r) {
    const m = msgFrom(r);
    S().commit((st) => {
      const c = st.chats.find((x) => x.id === r.conversation_id);
      const cur = c && c.messages.find((x) => x.id === r.id);
      if (cur) Object.assign(cur, m);
    });
  };
  SB.onProfile = function (p) {
    S().commit((st) => {
      const i = st.contacts.findIndex((c) => c.id === p.id);
      if (i >= 0) st.contacts[i] = Object.assign(contactFrom(p));
    });
  };

  SB.send = function (chatId, part) {
    const id = (crypto.randomUUID && crypto.randomUUID()) || U.uid('m');
    const m = Object.assign({ id, from: 'me', type: 'text', text: '', ts: Date.now(), status: 'sending' }, part);
    S().commit((st) => { const c = st.chats.find((x) => x.id === chatId); c.messages.push(m); c.draft = ''; c.unread = 0; });
    const row = { id, conversation_id: chatId, sender_id: SB.uid, kind: m.type, body: m.text || null, reply_to: m.replyTo || null,
      media_url: m.src || (m.file && m.file.url) || m.audio || null, file_name: m.file ? m.file.name : null, file_size: m.file ? m.file.size : null, duration: m.dur || null };
    SB.client.from('messages').insert(row).then(({ error }) => {
      S().commit((st) => {
        const cur = st.chats.find((x) => x.id === chatId).messages.find((x) => x.id === id);
        if (cur) cur.status = error ? 'failed' : (cur.status === 'sending' ? 'sent' : cur.status);
      });
      if (error) H.overlay.toast('Message not sent: ' + error.message);
    });
    return m;
  };

  SB.react = function (chatId, msgId, emoji) {
    const c = S().get().chats.find((x) => x.id === chatId);
    const m = c && c.messages.find((x) => x.id === msgId);
    if (!m) return;
    const mine = (m.reactions || []).find((r) => r.by === 'me');
    let next = (m.reactions || []).filter((r) => r.by !== 'me');
    if (!mine || mine.emoji !== emoji) next.push({ by: 'me', emoji });
    S().commit(() => { m.reactions = next; });
    SB.client.from('messages').update({ reactions: next.map((r) => ({ by: toDb(r.by), emoji: r.emoji })) }).eq('id', msgId).then(() => {});
  };

  SB.remove = function (chatId, msgId, forEveryone) {
    const c = S().get().chats.find((x) => x.id === chatId);
    const m = c && c.messages.find((x) => x.id === msgId);
    if (!m) return;
    if (forEveryone && m.from === 'me') {
      S().commit(() => { m.deleted = true; m.text = ''; m.reactions = []; delete m.src; delete m.file; delete m.audio; });
      SB.client.from('messages').update({ deleted: true, body: null, media_url: null, file_name: null, reactions: [] }).eq('id', msgId).then(() => {});
    } else {
      S().commit((st) => {
        const ch = st.chats.find((x) => x.id === chatId);
        ch.messages = ch.messages.filter((x) => x.id !== msgId);
        st.settings.hidden = (st.settings.hidden || []).concat(msgId);
      });
    }
  };

  SB.markRead = function (chatId) {
    const c = S().get().chats.find((x) => x.id === chatId);
    if (!c) return;
    if (c.unread) S().commit((st) => { st.chats.find((x) => x.id === chatId).unread = 0; });
    SB.client.from('messages').update({ status: 'read' }).eq('conversation_id', chatId).neq('sender_id', SB.uid).neq('status', 'read').then(() => {});
  };
  SB.markUnread = (chatId) => S().commit((st) => { const c = st.chats.find((x) => x.id === chatId); if (c) c.unread = Math.max(1, c.unread || 0); });
  SB.setDraft = (chatId, text) => S().commit((st) => { const c = st.chats.find((x) => x.id === chatId); if (c) c.draft = text; }, true);

  /* Typing indicator: a Realtime broadcast channel per conversation. */
  function typingChannel(chatId) {
    if (SB.typingChannels[chatId]) return SB.typingChannels[chatId];
    const ch = SB.client.channel('typing:' + chatId, { config: { broadcast: { self: false } } });
    ch.on('broadcast', { event: 'typing' }, ({ payload }) => {
      if (!payload || payload.uid === SB.uid) return;
      S().commit((st) => { const c = st.chats.find((x) => x.id === chatId); if (c) c.typing = !!payload.typing; });
      clearTimeout(SB.typingTimers[chatId]);
      if (payload.typing) SB.typingTimers[chatId] = setTimeout(() => S().commit((st) => { const c = st.chats.find((x) => x.id === chatId); if (c) c.typing = false; }), 4000);
    }).subscribe();
    SB.typingChannels[chatId] = ch;
    return ch;
  }
  SB.setTyping = function (chatId, on) {
    typingChannel(chatId).send({ type: 'broadcast', event: 'typing', payload: { uid: SB.uid, typing: on } });
  };
  SB.watchChat = (chatId) => { typingChannel(chatId); };

  SB.startChat = function (contactId) {
    const ex = S().get().chats.find((c) => c.contactId === contactId);
    if (ex) return ex.id;
    if (!S().get().contacts.find((c) => c.id === contactId) && SB.found[contactId]) {
      const ct = SB.found[contactId];
      S().commit((st) => { st.contacts.push(ct); }, true);
    }
    const [a, b] = [SB.uid, contactId].sort();
    const id = (crypto.randomUUID && crypto.randomUUID()) || U.uid('ch');
    S().commit((st) => { st.chats.unshift({ id, contactId, pinned: false, muted: false, archived: false, unread: 0, draft: '', messages: [] }); });
    SB.client.from('conversations').insert({ id, user_a: a, user_b: b }).then(({ error }) => {
      if (error) { H.overlay.toast('Could not start chat: ' + error.message); SB.loadAll(); }
    });
    return id;
  };

  SB.clearChat = (chatId) => S().commit((st) => { const c = st.chats.find((x) => x.id === chatId); if (c) { st.settings.hidden = (st.settings.hidden || []).concat(c.messages.map((m) => m.id)); c.messages = []; c.unread = 0; } });
  SB.deleteChat = (chatId) => SB.clearChat(chatId) || S().commit((st) => { st.chats = st.chats.filter((x) => x.id !== chatId); });
  SB.patchChat = (chatId, patch) => S().commit((st) => {
    Object.assign(st.chats.find((x) => x.id === chatId), patch);
    // pinned / muted / archived are kept in settings so they survive a restart (the server does not store them)
    const keep = {}; ['pinned', 'muted', 'archived'].forEach((k) => { if (k in patch) keep[k] = !!patch[k]; });
    if (Object.keys(keep).length) { st.settings.chatPrefs = st.settings.chatPrefs || {}; st.settings.chatPrefs[chatId] = Object.assign(st.settings.chatPrefs[chatId] || {}, keep); }
  });

  /* People search: by display name (3+ letters) or exact email. Runs on the server so the full user list never reaches the phone. */
  SB.search = async function (q) {
    q = String(q || '').trim();
    if (q.length < 3) return [];
    const { data, error } = await SB.client.rpc('search_users', { q });
    if (error) {
      if (/search_users|schema cache|does not exist/i.test(error.message || '')) throw new Error('Search is not set up yet. Run the newest schema.sql in the Supabase SQL editor.');
      throw error;
    }
    const mine = S().get().contacts.map((c) => c.id);
    const out = (data || []).filter((p) => p.id !== SB.uid).map(contactFrom);
    out.forEach((c) => { SB.found[c.id] = c; });
    return out.map((c) => Object.assign({}, c, { known: mine.includes(c.id) }));
  };
  SB.addContact = () => { H.overlay.toast('Contacts come from registered users in online mode.'); return null; };

  SB.updateProfile = async function (patch) {
    S().commit((st) => { Object.assign(st.me, patch); });
    const row = {};
    if ('name' in patch) row.display_name = patch.name;
    if ('about' in patch) row.about = patch.about;
    if ('avatar' in patch) row.avatar_url = patch.avatar;
    if (Object.keys(row).length) {
      const { error } = await SB.client.from('profiles').update(row).eq('id', SB.uid);
      if (error) H.overlay.toast('Could not save profile: ' + error.message);
    }
  };

  /* Media goes to the `media` Storage bucket under <user id>/<uuid>-<name>. */
  SB.upload = async function (file, kind) {
    let body = file; let type = file.type || 'application/octet-stream';
    if (kind === 'image' || kind === 'avatar') {
      const dataUrl = kind === 'avatar' ? await U.resizeImage(file, 320, 0.85, true) : await U.resizeImage(file, 1600, 0.82);
      body = await (await fetch(dataUrl)).blob(); type = 'image/jpeg';
    }
    if (body.size > 10 * 1048576) throw new Error('Files over 10 MB are not supported yet.');
    const safe = String(file.name || kind).replace(/[^\w.\-]+/g, '_').slice(-60);
    const path = SB.uid + '/' + ((crypto.randomUUID && crypto.randomUUID()) || U.uid('f')) + '-' + safe;
    const { error } = await SB.client.storage.from('media').upload(path, body, { contentType: type, upsert: false });
    if (error) throw error;
    const url = SB.client.storage.from('media').getPublicUrl(path).data.publicUrl;
    if (kind === 'image' || kind === 'avatar') return { src: url };
    if (kind === 'voice') return { audio: url };
    return { file: { name: file.name, size: file.size, url } };
  };

  H.backendSupabase = SB;
})(window.Halo = window.Halo || {});
