/* Halo — sidebar: header, search, Chats tab, Contacts tab, dock badges, long-press helper. */
(function (H) {
  'use strict';
  const U = H.U, C = H.C;
  const $ = (s, r = document) => r.querySelector(s);
  const L = {};

  /* Long-press (touch) and right-click (mouse) -> callback(element, {x, y}). */
  H.pressable = (root, sel, cb) => {
    let t, sx, sy, fired = false, last = 0;
    root.addEventListener('pointerdown', (e) => {
      if (e.pointerType === 'mouse') return;
      const el = e.target.closest(sel); if (!el) return;
      sx = e.clientX; sy = e.clientY; fired = false;
      clearTimeout(t);
      t = setTimeout(() => { fired = true; last = Date.now(); if (navigator.vibrate) { try { navigator.vibrate(12); } catch (x) { /* ignore */ } } cb(el, { x: sx, y: sy }); }, 430);
    });
    root.addEventListener('pointermove', (e) => { if (Math.abs(e.clientX - sx) > 10 || Math.abs(e.clientY - sy) > 10) clearTimeout(t); });
    ['pointerup', 'pointercancel', 'pointerleave'].forEach((n) => root.addEventListener(n, () => clearTimeout(t)));
    root.addEventListener('contextmenu', (e) => {
      const el = e.target.closest(sel); if (!el) return;
      e.preventDefault();
      if (Date.now() - last < 800) return;
      cb(el, { x: e.clientX, y: e.clientY });
    });
    root.addEventListener('click', (e) => { if (fired) { e.stopPropagation(); e.preventDefault(); fired = false; } }, true);
  };

  const st = () => H.store.get();
  const lastMsg = (c) => c.messages[c.messages.length - 1];
  const lastTs = (c) => (lastMsg(c) ? lastMsg(c).ts : 0);

  function snippet(c, q) {
    if (c.typing) return '<span class="snip typing"><span>typing…</span></span>';
    if (c.draft && H.session.openChat !== c.id && !q) return '<span class="snip"><span class="draft">Draft:</span><span>' + U.esc(c.draft) + '</span></span>';
    let m = lastMsg(c);
    if (q) { const hit = [...c.messages].reverse().find((x) => !x.deleted && ((x.text || '').toLowerCase().includes(q) || (x.file && x.file.name.toLowerCase().includes(q)))); if (hit) m = hit; }
    if (!m) return '<span class="snip"><span>No messages yet. Say hello!</span></span>';
    const tick = m.from === 'me' && !m.deleted ? C.tick(m.status || 'read') : '';
    let ic = '', txt;
    if (m.deleted) { ic = H.icon('info', 14); txt = m.from === 'me' ? 'You deleted this message' : 'This message was deleted'; }
    else if (m.type === 'image') { ic = H.icon('image', 15); txt = m.text || 'Photo'; }
    else if (m.type === 'voice') { ic = H.icon('mic', 15); txt = C.mmss(m.dur || 0); }
    else if (m.type === 'file') { ic = H.icon('file', 15); txt = m.file ? m.file.name : 'File'; }
    else txt = m.text;
    return '<span class="snip">' + tick + ic + '<span>' + (q ? C.hi(txt, q) : U.esc(txt)) + '</span></span>';
  }

  function chatRow(c, q) {
    const ct = H.store.contact(c.contactId); if (!ct) return '';
    const m = lastMsg(c);
    const unread = c.unread > 0;
    return '<button class="row ' + (unread ? 'has-unread ' : '') + (H.session.openChat === c.id ? 'active' : '') + '" data-chat="' + c.id + '" aria-label="Chat with ' + U.esc(ct.name) + (unread ? ', ' + c.unread + ' unread' : '') + '">' +
      C.avatar(ct, 54, ct.online) +
      '<span class="body"><span class="l1"><span class="name">' + (q ? C.hi(ct.name, q) : U.esc(ct.name)) + '</span><span class="when">' + (m ? U.listTime(m.ts) : '') + '</span></span>' +
      '<span class="l2">' + snippet(c, q) + (c.pinned ? '<span class="mini" title="Pinned">' + H.icon('pin', 15) + '</span>' : '') + (c.muted ? '<span class="mini" title="Muted">' + H.icon('bell-off', 15) + '</span>' : '') +
      (unread ? '<span class="badge ' + (c.muted ? 'muted' : '') + '">' + c.unread + '</span>' : '') + '</span></span></button>';
  }

  function setHtml(box, html) { if (box._h === html) return false; box._h = html; box.innerHTML = html; return true; }

  L.renderTop = () => {
    const tab = H.session.tab;
    const me = st().me;
    const theme = document.documentElement.dataset.theme;
    const left = tab === 'chats'
      ? '<div class="brand">' + H.logo(34) + 'Halo' + (H.backend && H.backend.mode === 'local' ? '<small>demo</small>' : '') + '</div>'
      : '<h1 class="page-title">' + (tab === 'contacts' ? 'Contacts' : 'Settings') + '</h1>';
    const html = left +
      '<button class="icon-btn" data-act="theme" aria-label="Switch to ' + (theme === 'dark' ? 'light' : 'dark') + ' theme" title="Toggle theme">' + H.icon(theme === 'dark' ? 'sun' : 'moon', 21) + '</button>' +
      '<button data-act="me" aria-label="Your profile">' + C.avatar(me, 40) + '</button>';
    setHtml($('#side-top'), html);
    const sw = $('#search-wrap'); sw.hidden = tab === 'settings';
    $('#search-input').placeholder = tab === 'contacts' ? 'Search contacts' : 'Search chats and messages';
    $('#search-input').setAttribute('aria-label', $('#search-input').placeholder);
    $('#fab').hidden = tab === 'settings';
    $('#fab').setAttribute('aria-label', tab === 'contacts' ? 'Add contact' : 'Start a new chat');
    $('#fab').innerHTML = H.icon(tab === 'contacts' ? 'user' : 'plus', 26);
  };

  L.renderChats = () => {
    const s = st();
    const q = H.session.q.trim().toLowerCase();
    const f = H.session.filter;
    let chats = s.chats.filter((c) => H.store.contact(c.contactId));
    const unreadN = chats.filter((c) => c.unread > 0).length;
    const onlineN = chats.filter((c) => H.store.contact(c.contactId).online).length;
    $('#pills').innerHTML = [['all', 'All', ''], ['unread', 'Unread', unreadN], ['online', 'Online', onlineN]]
      .map(([k, t, n]) => '<button class="pill ' + (f === k ? 'on' : '') + '" data-filter="' + k + '" aria-pressed="' + (f === k) + '">' + t + (n ? '<span class="n">' + n + '</span>' : '') + '</button>').join('');
    $('#pills').hidden = !!q;

    if (q) chats = chats.filter((c) => { const ct = H.store.contact(c.contactId); return ct.name.toLowerCase().includes(q) || c.messages.some((m) => !m.deleted && ((m.text || '').toLowerCase().includes(q) || (m.file && m.file.name.toLowerCase().includes(q)))); });
    else if (f === 'unread') chats = chats.filter((c) => c.unread > 0);
    else if (f === 'online') chats = chats.filter((c) => H.store.contact(c.contactId).online);
    chats.sort((a, b) => (b.pinned - a.pinned) || (lastTs(b) - lastTs(a)));

    let html = '';
    if (chats.length) html += '<div class="rows">' + chats.map((c) => chatRow(c, q)).join('') + '</div>';
    if (q) {
      const have = new Set(s.chats.map((c) => c.contactId));
      const more = s.contacts.filter((ct) => !have.has(ct.id) && ct.name.toLowerCase().includes(q));
      if (more.length) html += '<div class="group-h">Contacts</div><div class="rows">' + more.map(contactRow).join('') + '</div>';
      if (!chats.length && !more.length) html = C.empty('search', 'No results', 'Nothing matches “' + H.session.q.trim() + '”.');
    } else if (!chats.length) {
      html = f === 'all' ? C.empty('chat', 'No chats yet', 'Tap the + button to start your first conversation.') : C.empty('check', 'All caught up', f === 'unread' ? 'You have no unread chats.' : 'Nobody is online right now.');
    }
    setHtml($('#chat-rows'), html);
    const total = s.chats.reduce((n, c) => n + (c.muted ? 0 : c.unread || 0), 0);
    const nb = $('#dock-n'); nb.hidden = !total; nb.textContent = total > 99 ? '99+' : total;
    document.title = (total ? '(' + total + ') ' : '') + 'Halo';
  };

  function contactRow(ct) {
    return '<button class="row" data-contact="' + ct.id + '" aria-label="' + U.esc(ct.name) + '">' + C.avatar(ct, 50, ct.online) +
      '<span class="body"><span class="l1"><span class="name">' + U.esc(ct.name) + '</span></span><span class="l2"><span class="snip"><span>' + U.esc(ct.online ? 'Online · ' + ct.about : ct.about) + '</span></span></span></span></button>';
  }

  L.renderContacts = () => {
    const q = H.session.q.trim().toLowerCase();
    const list = st().contacts.filter((c) => !q || c.name.toLowerCase().includes(q) || (c.phone || '').includes(q)).sort((a, b) => a.name.localeCompare(b.name));
    let html = '';
    if (H.backend && H.backend.mode === 'local') {
      html += '<div class="rows"><button class="row" data-act="add-contact"><span class="av" style="--s:50px;--c1:var(--accent);--c2:var(--accent-2);color:var(--accent-ink)">' + H.icon('plus', 22) + '</span><span class="body"><span class="l1"><span class="name">New contact</span></span><span class="l2"><span class="snip"><span>Add someone to your list</span></span></span></span></button></div>';
    }
    if (!list.length) html += C.empty('users', q ? 'No matches' : 'No contacts yet', q ? 'Try a different name or number.' : 'People who join Halo will show up here.');
    else {
      let cur = '';
      list.forEach((ct) => {
        const l = ct.name[0].toUpperCase();
        if (l !== cur) { if (cur) html += '</div>'; cur = l; html += '<div class="group-h">' + l + '</div><div class="rows">'; }
        html += contactRow(ct);
      });
      html += '</div>';
    }
    setHtml($('#contact-rows'), html);
  };

  L.showTab = (tab) => {
    H.session.tab = tab;
    H.session.q = ''; $('#search-input').value = '';
    document.querySelectorAll('.tab').forEach((t) => t.classList.toggle('on', t.id === 'tab-' + tab));
    document.querySelectorAll('.dock button').forEach((b) => b.setAttribute('aria-selected', b.dataset.tab === tab ? 'true' : 'false'));
    L.renderTop(); L.renderAll();
    const bodyEl = $('#tab-' + tab); if (bodyEl) bodyEl.scrollTop = 0;
  };

  L.renderAll = () => {
    L.renderChats();
    if (H.session.tab === 'contacts') L.renderContacts();
    if (H.session.tab === 'settings') H.settings.render();
  };

  /* ---------- context menus and sheets ---------- */
  function chatMenu(el, pt) {
    const c = H.store.chat(el.dataset.chat); if (!c) return;
    H.overlay.menu({
      x: pt.x, y: pt.y,
      items: [
        { icon: 'pin', label: c.pinned ? 'Unpin chat' : 'Pin chat', fn: () => { if (!c.pinned && st().chats.filter((x) => x.pinned).length >= 3) return H.overlay.toast('You can pin up to 3 chats.'); H.backend.patchChat(c.id, { pinned: !c.pinned }); } },
        { icon: c.muted ? 'bell' : 'bell-off', label: c.muted ? 'Unmute notifications' : 'Mute notifications', fn: () => H.backend.patchChat(c.id, { muted: !c.muted }) },
        { icon: 'mail-dot', label: c.unread ? 'Mark as read' : 'Mark as unread', fn: () => (c.unread ? H.backend.markRead(c.id) : H.backend.markUnread(c.id)) },
        { icon: 'broom', label: 'Clear messages', danger: true, fn: () => H.chatView.clear(c.id) },
        { icon: 'trash', label: 'Delete chat', danger: true, fn: () => H.chatView.removeChat(c.id) }
      ]
    });
  }

  L.newChatSheet = () => {
    const s = st();
    const sh = H.overlay.sheet({
      title: 'New chat', flush: true,
      html: '<div style="padding:0 16px 8px"><div class="search"><span>' + H.icon('search', 18) + '</span><input class="input" id="nc-q" placeholder="Search name" aria-label="Search contacts"></div></div><div id="nc-list" class="rows"></div>',
      onMount(el) {
        const draw = () => {
          const q = el.querySelector('#nc-q').value.trim().toLowerCase();
          const list = s.contacts.filter((c) => !q || c.name.toLowerCase().includes(q)).sort((a, b) => a.name.localeCompare(b.name));
          el.querySelector('#nc-list').innerHTML = (H.backend.mode === 'local' ? '<button class="row" data-act="add-contact"><span class="av" style="--s:50px;--c1:var(--accent);--c2:var(--accent-2);color:var(--accent-ink)">' + H.icon('plus', 22) + '</span><span class="body"><span class="l1"><span class="name">New contact</span></span></span></button>' : '') +
            (list.length ? list.map(contactRow).join('') : C.empty('users', 'No one found', 'Try a different name.'));
        };
        draw();
        el.querySelector('#nc-q').addEventListener('input', draw);
        el.addEventListener('click', (e) => {
          const r = e.target.closest('[data-contact]');
          if (r) { sh.close(); H.nav.openChat(H.backend.startChat(r.dataset.contact)); }
          else if (e.target.closest('[data-act="add-contact"]')) { sh.close(); L.addContactSheet(); }
        });
      }
    });
  };

  L.addContactSheet = () => {
    const sh = H.overlay.sheet({
      title: 'New contact',
      html: '<label class="field"><span>Name</span><input class="input" id="ac-name" maxlength="40" placeholder="e.g. Maya Thapa" autocomplete="off"></label>' +
        '<label class="field"><span>Phone (optional)</span><input class="input" id="ac-phone" inputmode="tel" maxlength="24" placeholder="+977 98…"></label>' +
        '<p style="color:var(--fg3);font-size:.85em">Demo contacts are offline, so they will not reply. Use the seeded online contacts to see live-style replies.</p>' +
        '<button class="btn primary block" id="ac-save">Save contact</button>',
      onMount(el) {
        const go = () => {
          const name = el.querySelector('#ac-name').value.trim();
          if (!name) { el.querySelector('#ac-name').focus(); return H.overlay.toast('Enter a name first.'); }
          const id = H.backend.addContact(name, el.querySelector('#ac-phone').value.trim());
          sh.close(); H.overlay.toast(name + ' added', { action: { label: 'Message', fn: () => H.nav.openChat(H.backend.startChat(id)) } });
        };
        el.querySelector('#ac-save').onclick = go;
        el.querySelector('#ac-name').addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
      }
    });
  };

  L.contactSheet = (id) => {
    const ct = H.store.contact(id); if (!ct) return;
    const chat = st().chats.find((c) => c.contactId === id);
    const media = chat ? chat.messages.filter((m) => m.type === 'image' && !m.deleted).length : 0;
    const sh = H.overlay.sheet({
      title: '',
      html: '<div class="hero">' + C.avatar(ct, 104, ct.online) + '<h3>' + U.esc(ct.name) + '</h3><p>' + U.esc(ct.online ? 'Online' : U.lastSeen(ct.lastSeen)) + '</p></div>' +
        '<div class="kv"><small>About</small><span>' + U.esc(ct.about || '—') + '</span></div>' +
        (ct.phone ? '<div class="kv"><small>Phone</small><span>' + U.esc(ct.phone) + '</span></div>' : '') +
        (chat ? '<div class="kv"><small>Shared</small><span>' + chat.messages.length + ' messages · ' + media + ' photos</span></div>' : '') +
        '<div class="sheet-actions"><button class="btn primary" data-go>' + H.icon('chat', 18) + 'Message</button>' +
        (chat ? '<button class="btn" data-mute>' + H.icon(chat.muted ? 'bell' : 'bell-off', 18) + (chat.muted ? 'Unmute' : 'Mute') + '</button>' : '') + '</div>',
      onMount(el) {
        el.querySelector('[data-go]').onclick = () => { sh.close(); H.nav.openChat(H.backend.startChat(id)); };
        const m = el.querySelector('[data-mute]'); if (m) m.onclick = () => { H.backend.patchChat(chat.id, { muted: !chat.muted }); sh.close(); };
      }
    });
  };

  L.bind = () => {
    const side = $('.side');
    side.addEventListener('click', (e) => {
      const t = e.target;
      const r = t.closest('[data-chat]'); if (r) return H.nav.openChat(r.dataset.chat);
      const ct = t.closest('[data-contact]'); if (ct) return L.contactSheet(ct.dataset.contact);
      const f = t.closest('[data-filter]'); if (f) { H.session.filter = f.dataset.filter; return L.renderChats(); }
      const tb = t.closest('[data-tab]'); if (tb) return L.showTab(tb.dataset.tab);
      const a = t.closest('[data-act]');
      if (a) {
        if (a.dataset.act === 'theme') H.settings.set('theme', document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');
        else if (a.dataset.act === 'me') L.showTab('settings');
        else if (a.dataset.act === 'add-contact') L.addContactSheet();
      }
    });
    $('#fab').addEventListener('click', () => (H.session.tab === 'contacts' ? (H.backend.mode === 'local' ? L.addContactSheet() : L.newChatSheet()) : L.newChatSheet()));
    const inp = $('#search-input'), clr = $('#search-clear');
    inp.addEventListener('input', U.debounce(() => { H.session.q = inp.value; clr.hidden = !inp.value; L.renderChats(); if (H.session.tab === 'contacts') L.renderContacts(); }, 90));
    clr.addEventListener('click', () => { inp.value = ''; H.session.q = ''; clr.hidden = true; L.renderChats(); L.renderContacts(); inp.focus(); });
    H.pressable($('#chat-rows'), '[data-chat]', chatMenu);
  };

  H.lists = L;
})(window.Halo = window.Halo || {});
