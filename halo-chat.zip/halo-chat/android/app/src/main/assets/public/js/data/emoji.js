/* Halo — emoji picker data and the quick-reaction row. */
(function (H) {
  'use strict';
  const s = (str) => str.trim().split(/\s+/);
  H.emoji = [
    { id: 'smileys', icon: '😀', label: 'Smileys', list: s('😀 😃 😄 😁 😆 😅 😂 🤣 🥲 😊 😇 🙂 🙃 😉 😌 😍 🥰 😘 😋 😛 😜 🤪 🤨 🧐 🤓 😎 🥳 😏 😒 😞 😔 😟 🙁 😣 😫 🥺 😢 😭 😤 😠 🤯 😳 🥶 😱 😰 🤗 🤔 🫡 🤭 🤫 😐 😬 🙄 😴 🤤 😪 🥴 🤢 🤒') },
    { id: 'gestures', icon: '👍', label: 'Gestures', list: s('👍 👎 👌 🤌 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 ☝️ ✋ 🤚 🖐️ 🖖 👋 🤝 🙏 👏 🙌 🫶 💪 🫰 ✍️ 🤳') },
    { id: 'hearts', icon: '❤️', label: 'Hearts & symbols', list: s('❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 ✨ ⭐ 🌟 🔥 💯 ✅ ❌ ⚡ 🎉 🎊') },
    { id: 'nature', icon: '🌿', label: 'Nature', list: s('🌞 🌙 ⭐ ☁️ 🌧️ ⛈️ ❄️ 🌈 🌊 🔥 🌸 🌼 🌻 🌹 🌿 🍀 🌲 🌴 🏔️ 🌋 🐶 🐱 🦊 🐼 🐨 🦁 🐸 🐧 🦋 🐝') },
    { id: 'food', icon: '🍕', label: 'Food', list: s('🍎 🍊 🍋 🍌 🍉 🍇 🍓 🍑 🥭 🍍 🥑 🌽 🥕 🍞 🧀 🍳 🍔 🍟 🍕 🌮 🍜 🍣 🍩 🍪 🎂 🍫 ☕ 🍵 🥤 🍷') },
    { id: 'travel', icon: '✈️', label: 'Travel & things', list: s('✈️ 🚗 🚲 🚆 ⛵ 🏠 🏕️ 🗺️ 📍 📷 🎧 🎮 ⚽ 🏏 🎸 📚 💡 💻 📱 🔑 🎁 🎈 ⏰ 🧭') }
  ];
  H.quickReactions = ['👍', '❤️', '😂', '😮', '😢', '🙏', '🔥'];
})(window.Halo = window.Halo || {});
