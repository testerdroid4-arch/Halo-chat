#!/usr/bin/env node
/* Copies the web app into www/ (the folder Capacitor packages into the Android app). */
const fs = require('fs'); const path = require('path');
const root = path.join(__dirname, '..'); const out = path.join(root, 'www');
fs.rmSync(out, { recursive: true, force: true }); fs.mkdirSync(out, { recursive: true });
['index.html', 'manifest.webmanifest', 'sw.js'].forEach((f) => fs.copyFileSync(path.join(root, f), path.join(out, f)));
['css', 'js', 'icons'].forEach((d) => fs.cpSync(path.join(root, d), path.join(out, d), { recursive: true }));
console.log('Copied web app to www/');
