# Halo — glassmorphism messaging app

A complete, dependency-free chat app in plain HTML, CSS and JavaScript. It opens as a fully working
**offline demo** (simulated contacts, saved in `localStorage`) and can be switched to a **real online
backend** (accounts, real-time delivery, media uploads) by pasting two Supabase keys.

Original name, logo and artwork. Nothing from WhatsApp's brand or assets is used.

## Run it

| Way | Steps |
|---|---|
| Quickest | Double-click `index.html`. Works from `file://`. |
| Local server | `python3 -m http.server 8080` then open <http://localhost:8080> (or `npm start`) |
| Single file | `node tools/bundle.js` writes `dist/halo-standalone.html` (all CSS and JS inlined). Share or host that one file. |

Microphone recording and system notifications need `https://` or
`localhost`; they degrade gracefully on `file://`.

On Android, open the hosted URL in Chrome and use *Add to Home screen*. The layout is mobile-first and honours
safe areas, the keyboard (`interactive-widget`) and the system Back button (each open chat is a history entry).

## Install it as an app

**Android app (APK).** The project includes a complete Capacitor Android project in `android/`. This build
environment could not download the Android SDK, so the APK itself was **not compiled or run on a device here**.
Pick one route:

1. **No installs, in the cloud (easiest).** Create an empty GitHub repository, upload this folder, open
   *Actions → Build Android APK → Run workflow*. After a few minutes download the `halo-debug-apk` artifact,
   unzip it and copy `app-debug.apk` to your phone. Open it and allow *Install unknown apps* when asked.
2. **Android Studio.** Install Node 20+, JDK 21 and Android Studio, then
   ```
   npm install
   npm run android:open      # copies the web app into Android and opens the project
   ```
   Press *Run* with a phone plugged in, or *Build → Build APK(s)*.
3. **Command line.** With the Android SDK installed (`ANDROID_HOME` set): `npm install && npm run android:apk`.
   The file appears at `android/app/build/outputs/apk/debug/app-debug.apk`.

After changing anything in `css/`, `js/` or `index.html`, run `npm run android:sync` before building again.
`js/config.js` (your Supabase keys) is copied into the app, so set it first.

The debug APK is signed with a debug key: fine for your own phone and testers. For Google Play you need a release
build signed with your own keystore (*Build → Generate Signed Bundle / APK* in Android Studio) and a new
`appId` in `capacitor.config.json` if `com.halochat.app` is taken.

Inside the app, voice notes use the microphone and the camera button opens the camera (Android asks permission).
Browser-style system notifications do not exist in the Android WebView, so alerts show in-app; push notifications
while the app is closed would need Firebase Cloud Messaging.

**Installable web app (PWA).** Host the folder on any HTTPS static host (Netlify, Cloudflare Pages, GitHub Pages),
open it in Chrome on Android and choose *Install app* from the menu. It gets the Halo icon, runs full screen and the
app shell works offline.

## What you get

- **Dashboard**: glass chat list with avatars, online dots, unread badges, pinned/muted markers, typing state,
  drafts, filters (All / Unread / Online), and search across names and message text (`Ctrl/Cmd K`).
- **Conversation**: bubbles with day separators, timestamps, delivery and read ticks, replies with quote jump,
  reactions (long-press, right-click, ⌄ button or double-click for ❤️), delete for me / for everyone,
  copy, in-chat search with next/previous, jump-to-latest button, link detection, large single-emoji messages.
- **Composer**: auto-growing field, emoji picker with recents, photo picker with caption preview, camera capture,
  file attach, drag-and-drop, paste-an-image, voice notes (real microphone recording, waveform playback).
- **Contacts, profile, settings**: editable name, about and photo; dark / light / auto theme; five chat themes;
  text size; lighter-effects switch; notification, privacy and Enter-key preferences.
- **Persistence**: chats, drafts, profile and settings survive reload (`localStorage`, key `halo.v1`).
- **Accessibility**: labelled controls, `aria-live` message log, `role=switch` toggles, dialog semantics,
  visible focus rings, Esc closes layers, `prefers-reduced-motion` respected.

## Folder structure

```
halo-chat/
├── index.html                 App shell (static markup, script order)
├── css/
│   ├── base.css               Tokens, themes, aurora background, glass, buttons, avatars, switches
│   ├── layout.css             Shell, sidebar, lists, dock navigation, settings, desktop two-pane
│   └── chat.css               Conversation, bubbles, composer, sheets, menus, toasts, auth card
├── js/
│   ├── config.js              ← put your Supabase URL + anon key here (optional)
│   ├── app.js                 Boot, theme application, hash navigation
│   ├── core/                  utils.js · icons.js (SVG set) · store.js (state + localStorage)
│   ├── data/                  seed.js (sample chats/personas) · emoji.js
│   ├── services/
│   │   ├── backend-local.js       Simulated backend (default)
│   │   ├── backend-supabase.js    Real backend adapter (auth, DB, realtime, storage)
│   │   └── notify.js              Banner, chime, system notifications
│   └── ui/                    components.js · overlay.js · lists.js · chatview.js · settings.js · auth.js
├── backend/supabase/schema.sql   Tables, RLS policies, realtime, storage bucket
├── manifest.webmanifest · sw.js · icons/   Installable web app (PWA)
├── android/                   Capacitor Android project (build with Android Studio or CI)
├── capacitor.config.json      App id, name, web folder
├── .github/workflows/android.yml   Cloud APK build
├── assets/                    Icon and splash sources (npm run assets regenerates Android icons)
├── tools/bundle.js            Builds the single-file version
├── tools/build-web.js         Copies the web app into www/ for Android
└── dist/halo-standalone.html  Built output
```

All modules attach to one `window.Halo` namespace, so no bundler or ES-module server is needed.

## Simulated vs real

**Offline demo (default)**

| Real on your device | Simulated (scripted timers, no network) |
|---|---|
| Saving chats, drafts, settings (`localStorage`) | Contacts and their replies, typing indicators |
| Photo resize and storage, file picking | Delivered and read ticks from the other side |
| Microphone voice notes (with permission) | Online / last-seen state of contacts |
| Search, reactions, replies, deletes, themes | Anyone else receiving your messages |
| Browser notification permission, chime | Contents of attached files (only name and size kept) |

**Online mode (after the Supabase setup below)**

| Real | Not included yet |
|---|---|
| Email sign-up / sign-in | End-to-end encryption |
| Messages in Postgres, protected by row-level security | Push notifications when the app is closed |
| Real-time delivery between signed-in users | Group chats, phone-number contact discovery |
| Delivered/read status written by the receiving device | Server-side hiding of read receipts / last seen |
| Typing indicator (Realtime broadcast), presence heartbeat | Private media bucket with signed URLs |
| Photos, files, voice notes in Supabase Storage | Message editing, forwarding, calls |

> The Supabase adapter was checked against an in-memory fake of the supabase-js client (sign-in, load, send,
> realtime insert/update, start chat) but **not against a live Supabase project**. Expect to adjust small
> details when you run it for the first time.

## Go online with Supabase

1. Create a project at <https://supabase.com>.
2. **SQL editor** → paste and run `backend/supabase/schema.sql`.
3. **Authentication → Providers → Email**: for quick testing turn off *Confirm email*.
4. **Project Settings → API**: copy the *Project URL* and the *anon public* key into `js/config.js`:
   ```js
   window.HALO_CONFIG = { supabaseUrl: 'https://xxxx.supabase.co', supabaseAnonKey: 'eyJ…' };
   ```
   Never use the `service_role` key in front-end code.
5. Serve the app over `http://localhost` or `https://` and reload. A sign-in card appears.
6. Register two accounts in two browsers (or one normal and one private window). They appear in each other's
   Contacts; start a chat and messages arrive live.

If the backend cannot be reached, the app offers to continue with the offline demo.

### How the backend is wired

`js/ui/*` only talks to `Halo.backend`, an interface with the same methods in both adapters:
`init, send, react, remove, markRead, markUnread, setTyping, setDraft, startChat, clearChat, deleteChat,
patchChat, addContact, updateProfile, upload` (plus `signIn / signUp / signOut` online).
The UI renders from one state tree (`Halo.store`), so a new adapter only has to keep that tree up to date.

**Using Firebase instead:** copy `backend-supabase.js` to `backend-firebase.js` and map the calls:
Auth → `signInWithEmailAndPassword`, profiles/conversations/messages → Firestore collections with
`onSnapshot` listeners (replace `subscribe`), media → Cloud Storage `uploadBytes`, typing/presence →
Realtime Database `onDisconnect`. Security Rules replace the RLS policies in `schema.sql`.

### Hardening checklist before real users

- Replace the open profile directory with invites, usernames or hashed phone/email lookup.
- Make the `media` bucket private and serve signed URLs; add size and type limits server-side.
- Restrict `messages` updates by column (read status / reactions) with a security-definer function.
- Use private Realtime channels (authorised via `realtime.messages` policies) for typing events.
- Add push notifications (service worker + Web Push or FCM) and rate limiting.
- Add moderation, abuse reporting and a data-retention policy; consider E2E encryption (e.g. libsignal).

## Customising

- Colours, radii, blur: tokens at the top of `css/base.css`. Chat themes: the `[data-chattheme]` blocks.
- Sample people and conversations: `js/data/seed.js`. Reply personalities: `H.personas`.
- Reset the offline demo by clearing the `halo.v1` key in browser storage.

## Known limits

- `localStorage` holds roughly 5 MB; photos are downscaled (≈1100 px) and voice notes over ~100 s are stored without audio in demo mode.
- Blur effects are GPU-heavy on very old Android phones: enable *Lighter effects* in Settings.
- Tested in headless Chromium (mobile 393×800 and desktop 1360×820). Safari and Firefox were not exercised.

## People search, archive and message selection

- **Finding people (online mode):** nobody is listed up front. The Contacts tab shows only people you already chat with.
  To start a chat, search by display name (3+ letters) or an exact email address. The search runs on the server
  (`search_users()` in `backend/supabase/schema.sql`), returns at most 20 people and never returns anyone's email.
  Profiles are visible only to yourself and your chat partners. **Re-run `schema.sql` once** after updating the app.
- **Archive:** long-press a chat (or use the chat menu) > *Archive chat*. Archived chats move to an **Archived** row at the
  top of the list. Sending a message to an archived chat brings it back. In online mode pin / mute / archive are
  remembered on the device.
- **Messages:** long-press a message for reactions, Reply, Copy, **Select** and Delete. In select mode tap more
  messages, then copy, reply (one message) or delete (for me / for everyone for your own messages).
