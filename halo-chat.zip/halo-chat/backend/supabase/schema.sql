-- Halo · Supabase schema. Run in the Supabase SQL editor. Safe to run more than once.
-- Gives you: profiles, 1:1 conversations, messages (text/image/file/voice), row-level security,
-- realtime publication and a public "media" storage bucket.

-- 1. Profiles ---------------------------------------------------------------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'New user',
  about text default 'Hey there! I am using Halo.',
  avatar_url text,
  last_seen timestamptz default now(),
  created_at timestamptz default now()
);

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email, '@', 1)));
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- 2. Conversations (one row per pair; user_a < user_b keeps pairs unique) ------
create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  user_a uuid not null references public.profiles(id) on delete cascade,
  user_b uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz default now(),
  check (user_a < user_b),
  unique (user_a, user_b)
);

-- 3. Messages ---------------------------------------------------------------
create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  kind text not null default 'text' check (kind in ('text','image','file','voice')),
  body text,
  media_url text,
  file_name text,
  file_size bigint,
  duration int,
  reply_to uuid references public.messages(id) on delete set null,
  reactions jsonb not null default '[]'::jsonb,
  status text not null default 'sent' check (status in ('sent','delivered','read')),
  deleted boolean not null default false,
  created_at timestamptz default now()
);
create index if not exists messages_conv_time on public.messages (conversation_id, created_at desc);

-- 4. Row-level security --------------------------------------------------------
alter table public.profiles enable row level security;
alter table public.conversations enable row level security;
alter table public.messages enable row level security;

create or replace function public.is_member(conv uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.conversations c
    where c.id = conv and (c.user_a = auth.uid() or c.user_b = auth.uid()));
$$;

drop policy if exists "profiles readable by signed-in users" on public.profiles;
create policy "profiles readable by signed-in users" on public.profiles for select to authenticated using (true);
drop policy if exists "users edit own profile" on public.profiles;
create policy "users edit own profile" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

drop policy if exists "members read conversations" on public.conversations;
create policy "members read conversations" on public.conversations for select to authenticated
  using (user_a = auth.uid() or user_b = auth.uid());
drop policy if exists "users start conversations" on public.conversations;
create policy "users start conversations" on public.conversations for insert to authenticated
  with check (user_a = auth.uid() or user_b = auth.uid());

drop policy if exists "members read messages" on public.messages;
create policy "members read messages" on public.messages for select to authenticated using (public.is_member(conversation_id));
drop policy if exists "members send as themselves" on public.messages;
create policy "members send as themselves" on public.messages for insert to authenticated
  with check (sender_id = auth.uid() and public.is_member(conversation_id));
-- Members may update messages (read status, reactions, delete-for-everyone).
-- HARDENING TODO: restrict columns per role with a security-definer RPC or column-level triggers.
drop policy if exists "members update messages" on public.messages;
create policy "members update messages" on public.messages for update to authenticated
  using (public.is_member(conversation_id)) with check (public.is_member(conversation_id));

-- 5. Realtime ------------------------------------------------------------------
-- Safe to re-run: skips tables that are already in the publication.
do $$
declare t text;
begin
  foreach t in array array['messages','conversations','profiles'] loop
    if not exists (
      select 1 from pg_publication_tables
      where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = t
    ) then
      execute format('alter publication supabase_realtime add table public.%I', t);
    end if;
  end loop;
end $$;

-- 6. Storage bucket for images, files and voice notes ---------------------------
-- Public for simplicity (URLs are unguessable). For production use a private bucket + signed URLs.
insert into storage.buckets (id, name, public) values ('media', 'media', true) on conflict (id) do nothing;

drop policy if exists "signed-in users upload to own folder" on storage.objects;
create policy "signed-in users upload to own folder" on storage.objects for insert to authenticated
  with check (bucket_id = 'media' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "media is readable" on storage.objects;
create policy "media is readable" on storage.objects for select using (bucket_id = 'media');
